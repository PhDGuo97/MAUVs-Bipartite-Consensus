
%% ============================================
% Steady-State RMSE Calculation for Five AUVs
% Time interval: 2 s - 10 s
% =============================================

T_ss = 2;
T_sim = 10;
N = 5;

%% 1. Read Simulink data

if isa(input, 'timeseries')

    time = input.Time(:);
    data = squeeze(input.Data);

elseif isstruct(input)

    time = input.time(:);
    data = squeeze(input.signals.values);

elseif isnumeric(input)

    data = input;

    if exist('tout', 'var')
        time = tout(:);
    elseif exist('t', 'var')
        time = t(:);
    else
        error('Cannot find simulation time vector.');
    end

else
    error('Unsupported input data format.');
end

%% 2. Check data dimensions

fprintf('Time samples: %d\n', numel(time));
disp('Original data size:');
disp(size(data));

% Ensure each row represents a time sample
if size(data,1) == numel(time)
    % Correct orientation
elseif size(data,2) == numel(time)
    data = data.';
else
    error('Data size does not match time samples.');
end

if size(data,2) < 60
    error('Input must contain at least 60 channels.');
end

%% 3. Extract position and velocity errors

Ep = data(:,31:45);
Ev = data(:,46:60);

%% 4. Select steady-state time interval

idx = (time >= T_ss) & (time <= T_sim);

time_ss = time(idx);
Ep_ss = Ep(idx,:);
Ev_ss = Ev(idx,:);

if numel(time_ss) < 2
    error('Not enough samples between 2 and 10 seconds.');
end

%% 5. Calculate RMSE for each error component

RMSE_p = zeros(5,3);
RMSE_v = zeros(5,3);

for i = 1:N

    for k = 1:3

        col = 3*(i-1) + k;

        ep = Ep_ss(:,col);
        ev = Ev_ss(:,col);

        RMSE_p(i,k) = sqrt( ...
            trapz(time_ss,ep.^2) / (T_sim-T_ss));

        RMSE_v(i,k) = sqrt( ...
            trapz(time_ss,ev.^2) / (T_sim-T_ss));

    end

end

%% 6. Calculate overall RMSE for each AUV

RMSE_p_AUV = zeros(N,1);
RMSE_v_AUV = zeros(N,1);

for i = 1:N

    RMSE_p_AUV(i) = sqrt(sum(RMSE_p(i,:).^2));

    RMSE_v_AUV(i) = sqrt(sum(RMSE_v(i,:).^2));

end

%% 7. Overall RMSE according to paper

RMSE_p_total = sqrt(sum(RMSE_p_AUV.^2)/N);
RMSE_v_total = sqrt(sum(RMSE_v_AUV.^2)/N);

%% 8. Display results

fprintf('\n======= Position RMSE =======\n');

for i = 1:N
    fprintf('AUV %d: X=%.6f Y=%.6f Z=%.6f\n', ...
        i,RMSE_p(i,1),RMSE_p(i,2),RMSE_p(i,3));
end

fprintf('\n======= Velocity RMSE =======\n');

for i = 1:N
    fprintf('AUV %d: X=%.6f Y=%.6f Z=%.6f\n', ...
        i,RMSE_v(i,1),RMSE_v(i,2),RMSE_v(i,3));
end

fprintf('\nOverall position RMSE = %.6f\n', ...
    RMSE_p_total);

fprintf('Overall velocity RMSE = %.6f\n', ...
    RMSE_v_total);

%% 9. Export to Excel

AUV = (1:N)';

Result = table(AUV, ...
    RMSE_p(:,1),RMSE_p(:,2),RMSE_p(:,3), ...
    RMSE_v(:,1),RMSE_v(:,2),RMSE_v(:,3), ...
    'VariableNames', ...
    {'AUV','RMSE_px','RMSE_py','RMSE_pz', ...
    'RMSE_vx','RMSE_vy','RMSE_vz'});

disp(Result);

writetable(Result,'Steady_State_RMSE.xlsx');
