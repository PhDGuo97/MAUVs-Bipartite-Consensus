clc
clear
close all
load("data.mat")




%% === Event-triggered "matchstick" plots ===
%  out.tout : [N×1] time
%  out.tri  : [N×6] triggers (columns = trig1..trig5, trigAny)

t  = out.tout(:);
tri = out.tri;



num_ones1 = sum(tri(:,1));
num_ones2 = sum(tri(:,2));
num_ones3 = sum(tri(:,3));
num_ones4 = sum(tri(:,4));
num_ones5 = sum(tri(:,5));
% Make tri match t's orientation if needed
if size(tri,1) ~= numel(t) && size(tri,2) == numel(t)
    tri = tri.';  % [6×N] -> [N×6]
end
assert(size(tri,1) == numel(t), 'out.tri rows must equal length(out.tout)');

nFollower = min(5, size(tri,2));
cols = lines(nFollower);

% ===== 触发模式 =====
% 'sample' : 每个 trig==1 的采样点都算一次触发（你现在需要）
% 'edge'   : 仅 0->1 上升沿算一次触发
trigger_mode = 'sample';

%% -------------------------------------------------------------
% 1) 事件时刻火柴图（每次触发一根竖线）
% -------------------------------------------------------------
figure('Name','Event Times (Matchstick Plot)','Color','w');
for i = 1:nFollower
    trig = tri(:,i) > 0.5;

    % 根据模式取事件索引
    if strcmp(trigger_mode,'edge')
        idx = find([false; diff(trig)==1]);   % 上升沿
    else
        idx = find(trig);                     % 每个为1的采样点
    end

    te = t(idx);

    subplot(nFollower,1,i); hold on;
    if ~isempty(te)
        line([te.'; te.'], [zeros(1,numel(te)); ones(1,numel(te))], ...
             'Color', cols(i,:), 'LineWidth', 0.8);
    end
    ylim([0 1]); yticks([]); box on;
    ylabel(sprintf('Follower%d', i));
    if i==nFollower, xlabel('Time (s)'); end
    title(sprintf('Event Times (Mode: %s)', trigger_mode));
end
count = 0 ;
%% -------------------------------------------------------------
% 2) 触发间隔火柴图（高度 = 相邻触发时间差 Δt）
% -------------------------------------------------------------
figure('Name','Event Intervals (Stem Plot)','Color','w');
for i = 1:nFollower
    trig = tri(:,i) > 0.5;
     count = 0 ;
    if strcmp(trigger_mode,'edge')
        idx = find([false; diff(trig)==1]);
    else
        idx = find(trig);
    end

    te = t(idx);
    Ti = [NaN; diff(te)];   % 首个无前驱

    subplot(nFollower,1,i);
    if ~isempty(te)
        count = count+1;
        disp("count")
        disp(count);
        stem(te, Ti, 'o', ...
            'Color', cols(i,:), ...
            'MarkerFaceColor', 'none', ...   % <<< 空心圆
            'MarkerEdgeColor', cols(i,:), ...
            'LineWidth', 1.0);
       
    else
        stem(NaN, NaN);
    end
    grid on; box on;
    ylabel({'$T_{in} $'}, 'Interpreter', 'latex');
    legend(sprintf('AUV%d', i), 'Location','northeast','FontSize', 10);
    set(gca, 'FontSize', 8, 'TickLabelInterpreter', 'latex');
    % 在顶部创建共享图例
% 创建共享图例（放在最上方）
% legend_labels = {'AUV1', 'AUV2', 'AUV3', 'AUV4', 'AUV5'};
% 
% % 方法1：使用annotation创建图例
% ax_legend = axes('Position', [0.3 0.92 0.4 0.05], 'Visible', 'off'); % 调整位置
% legend(ax_legend, legend_labels, ...
%        'Orientation', 'horizontal', ...
%        'NumColumns', 5, ...  % 水平排列7个图例项
%        'Box', 'off', ...
%        'FontSize', 8);
    if i==nFollower, xlabel('Time (s)'); end
    % title('Event Intervals');
end


%% -------------------------------------------------------------
% % 3) (可选) 合并触发 trigAny（第6列）
% % -------------------------------------------------------------
% if size(tri,2) >= 6
%     trigAny = tri(:,6) > 0.5;
%     if strcmp(trigger_mode,'edge')
%         idxAny = find([false; diff(trigAny)==1]);
%     else
%         idxAny = find(trigAny);
%     end
%     teAny = t(idxAny);
% 
%     figure('Name','Combined Trigger (trigAny)','Color','w'); hold on;
%     if ~isempty(teAny)
%         line([teAny.'; teAny.'], [zeros(1,numel(teAny)); ones(1,numel(teAny))], ...
%              'Color','k','LineWidth',0.8);
%     end
%     ylim([0 1]); yticks([]); box on;
%     xlabel('Time (s)'); ylabel('trigAny');
%     title(sprintf('Combined Event Times (Mode: %s)', trigger_mode));
% end




%% ============================================
% Event-triggered intervals and event counting
% =============================================

% Required variables:
% t            : Simulation time vector
% tri          : Trigger signal matrix (samples x N)
% nFollower    : Number of follower AUVs
% trigger_mode : 'edge' or 'pulse'
% cols         : Colors for each AUV



%% Parameters
T_start = 0;
T_end = 10;        % Simulation end time
h = 0.01;          % Reference sampling interval (modify)

% Include the initial update at t=0?
count_initial = false;

%% Data validation
if size(tri,1) ~= length(t) && ...
        size(tri,2) == length(t)
    tri = tri';
end

assert(size(tri,1) == length(t), ...
    'Time and triggering signal dimensions do not match.');

assert(size(tri,2) >= nFollower, ...
    'Insufficient triggering signal channels.');

%% Initialize statistics
N_event = zeros(nFollower,1);
Reduction = zeros(nFollower,1);
MeanInterval = NaN(nFollower,1);
MinInterval = NaN(nFollower,1);
MaxInterval = NaN(nFollower,1);

% Reference periodic update count
% Counting convention: exclude initial update
N_total = round((T_end-T_start)/h);

%% Figure
fig = figure('Name','Event Intervals', ...
    'Color','w', ...
    'Position',[200 100 850 900]);

for i = 1:nFollower

    %% 1. Detect triggering events
    trig = tri(:,i) > 0.5;

    if strcmpi(trigger_mode,'edge')

        % Detect 0 -> 1 rising edges
        idx = find(diff([false; trig]) == 1);

    else

        % Each true sample represents one event
        idx = find(trig);

    end

    %% 2. Extract triggering instants
    te = t(idx);

    % Limit to the evaluation interval
    te = te(te >= T_start & te <= T_end);

    % Exclude or include the initial update
    if ~count_initial
        te = te(te > T_start);
    end

    %% 3. Count events
    N_event(i) = numel(te);

    %% 4. Calculate inter-event intervals
    if numel(te) >= 2

        Ti = diff(te);

        MeanInterval(i) = mean(Ti);
        MinInterval(i) = min(Ti);
        MaxInterval(i) = max(Ti);

    else

        Ti = [];

    end

    %% 5. Calculate reduction percentage
    Reduction(i) = ...
        (1 - N_event(i)/N_total)*100;

    %% 6. Plot event intervals
    subplot(nFollower,1,i);
    hold on; grid on; box on;

    if numel(te) >= 2

        stem(te(2:end),Ti,'o', ...
            'Color',cols(i,:), ...
            'MarkerFaceColor','none', ...
            'MarkerEdgeColor',cols(i,:), ...
            'LineWidth',1.0, ...
            'MarkerSize',4);

    else
        plot(NaN,NaN,'Color',cols(i,:));
    end

    ylabel('$T_{in}$ (s)', ...
        'Interpreter','latex','FontSize',11);

    legend(sprintf('AUV %d',i), ...
        'Location','northeast', ...
        'FontSize',10);

    xlim([T_start T_end]);

    set(gca,'FontSize',10, ...
        'TickLabelInterpreter','latex');

    if i == nFollower
        xlabel('Time (s)','FontSize',11);
    end

    %% 7. Display individual counts
    fprintf('AUV %d: %d triggering events\n', ...
        i,N_event(i));

end

%% ============================================
% Statistical results
% =============================================

AUV = (1:nFollower)';

Result = table(AUV,N_event,Reduction, ...
    MeanInterval,MinInterval,MaxInterval, ...
    'VariableNames', ...
    {'AUV','EventCount','ReductionPercent', ...
     'MeanInterval_s','MinInterval_s', ...
     'MaxInterval_s'});

disp('========== Event Triggering Statistics ==========');
disp(Result);

%% Total and average statistics
N_event_total = sum(N_event);
N_event_average = mean(N_event);
Reduction_average = mean(Reduction);

fprintf('\n====================================\n');
fprintf('Reference updates per AUV: %d\n',N_total);
fprintf('Total triggering events: %d\n',N_event_total);
fprintf('Average events per AUV: %.2f\n', ...
    N_event_average);
fprintf('Average reduction: %.2f %%\n', ...
    Reduction_average);
fprintf('====================================\n');

%% Export results
writetable(Result,'Event_Trigger_Statistics.xlsx');

%% Export figure
exportgraphics(fig,'Event_Intervals.png', ...
    'Resolution',600);






%% ================= 1. 数据 =================
x_labels = {'AUV1','AUV2','AUV3','AUV4','AUV5'};

% 触发事件次数
trigger_events = [337, 350, 348, 335, 326];

% 控制更新利用率 (%)
utilization = [66.3, 65.0, 65.2, 66.5, 67.4];

x = 1:length(x_labels);

%% ================= 2. 颜色设置 =================
barColor   = [0.78 0.78 0.78];       % 灰色柱状图
rightColor = [0.8500 0.3250 0.0980]; % 橙色折线及右轴
blackColor = [0 0 0];

%% ================= 3. 创建画布 =================
fig = figure('Color','w', ...
    'Position',[200 200 950 600]);

ax = axes('Parent',fig);
hold(ax,'on');

%% ================= 4. 左侧柱状图 =================
yyaxis left

b = bar(x, trigger_events, 0.75, ...
    'FaceColor',barColor, ...
    'EdgeColor','k', ...
    'LineWidth',1.2);

ylabel('Number of triggering events', ...
    'FontSize',18, ...
    'FontName','Times New Roman', ...
    'Color',blackColor);

ylim([0 450]);
yticks(0:50:450);

% 左侧坐标轴颜色
ax.YAxis(1).Color = blackColor;

% 柱顶数值标注
for i = 1:length(trigger_events)

    text(x(i),trigger_events(i)+8, ...
        num2str(trigger_events(i)), ...
        'HorizontalAlignment','center', ...
        'VerticalAlignment','bottom', ...
        'FontSize',16, ...
        'FontWeight','bold', ...
        'FontName','Times New Roman', ...
        'Color','k');

end

%% ================= 5. 右侧折线图 =================
yyaxis right

p = plot(x,utilization,'-o', ...
    'Color',rightColor, ...
    'LineWidth',2.2, ...
    'MarkerSize',9, ...
    'MarkerFaceColor','w', ...
    'MarkerEdgeColor',rightColor, ...
    'MarkerEdgeColor',rightColor);

ylabel('Control-update utilization (%)', ...
    'FontSize',18, ...
    'FontName','Times New Roman', ...
    'Color',rightColor);

% 右侧纵坐标范围
ylim([60 70]);
yticks(60:2:70);

% 关键设置：右侧坐标轴、刻度及刻度数字变橙色
ax.YAxis(2).Color = rightColor;

% 百分比标注
for i = 1:length(utilization)

    text(x(i),utilization(i)-0.45, ...
        sprintf('%.1f%%',utilization(i)), ...
        'HorizontalAlignment','center', ...
        'VerticalAlignment','top', ...
        'FontSize',15, ...
        'FontWeight','bold', ...
        'FontName','Times New Roman', ...
        'Color',rightColor);

end

%% ================= 6. 坐标轴设置 =================

ax.XTick = x;
ax.XTickLabel = x_labels;

% 缩小柱状图左右留白
xlim([0.6 5.4]);

ax.FontSize = 17;
ax.FontName = 'Times New Roman';
ax.LineWidth = 1.2;

ax.Box = 'on';
ax.TickDir = 'in';
ax.TickLength = [0.012 0.012];

% 横坐标轴保持黑色
ax.XColor = 'k';

% 左右两侧纵坐标颜色
ax.YAxis(1).Color = blackColor;
ax.YAxis(2).Color = rightColor;

% 网格
grid on;
ax.GridLineStyle = '-';
ax.GridColor = [0.82 0.82 0.82];
ax.GridAlpha = 0.65;
ax.Layer = 'top';

%% ================= 7. 图例 =================
lgd = legend([b,p], ...
    {'Triggering events','Utilization R_c'}, ...
    'Location','northwest', ...
    'Orientation','horizontal', ...
    'FontName','Times New Roman', ...
    'FontSize',15, ...
    'Box','on');

lgd.EdgeColor = 'k';
lgd.Color = 'w';

%% ================= 8. 输出高清图片 =================

% 300 dpi PNG
exportgraphics(fig,'AUV_triggering_events.png', ...
    'Resolution',300);

% 矢量 PDF
exportgraphics(fig,'AUV_triggering_events.pdf', ...
    'ContentType','vector');

% 矢量 EPS
print(fig,'AUV_triggering_events','-depsc','-painters');

disp('图片绘制完成！');





%% 数据
x_labels = {'AUV1','AUV2','AUV3','AUV4','AUV5'};
trigger_events = [337, 350, 348, 335, 326];
utilization = [66.3, 65.0, 65.2, 66.5, 67.4];

x = 1:length(x_labels);

% 橙色
rightColor = [0.8500 0.3250 0.0980];

%% 画图
figure('Color','w','Position',[200 200 900 550]);

% 左坐标轴：柱状图
yyaxis left
b = bar(x, trigger_events, 0.6, ...
    'FaceColor',[0.75 0.75 0.75], ...
    'EdgeColor','k', ...
    'LineWidth',1.2);

ylabel('Number of triggering events', ...
    'FontSize',16, ...
    'FontName','Times New Roman');

ylim([0 450]);
yticks(0:50:450);

% 柱顶标注
for i = 1:length(trigger_events)
    text(x(i), trigger_events(i)+8, num2str(trigger_events(i)), ...
        'HorizontalAlignment','center', ...
        'VerticalAlignment','bottom', ...
        'FontSize',16, ...
        'FontWeight','bold', ...
        'FontName','Times New Roman');
end

%% 右坐标轴：折线图
yyaxis right

p = plot(x, utilization, '-o', ...
    'Color', rightColor, ...
    'LineWidth', 2.2, ...
    'MarkerSize', 10, ...
    'MarkerFaceColor', 'w', ...
    'MarkerEdgeColor', rightColor);

ylabel('Control-update utilization (%)', ...
    'FontSize',16, ...
    'Color',rightColor, ...
    'FontName','Times New Roman');

ylim([60 70]);
yticks(60:2:70);

% ===== 新增：右侧坐标轴及刻度数字变为橙色 =====
ax = gca;
ax.YAxis(2).Color = rightColor;

% 百分比标注
for i = 1:length(utilization)
    text(x(i), utilization(i)-0.9, ...
        sprintf('%.1f%%', utilization(i)), ...
        'HorizontalAlignment','center', ...
        'VerticalAlignment','top', ...
        'FontSize',16, ...
        'FontWeight','bold', ...
        'Color',rightColor, ...
        'FontName','Times New Roman');
end

%% 坐标轴设置
ax = gca;
ax.XTick = x;
ax.XTickLabel = x_labels;
ax.FontSize = 16;
ax.FontName = 'Times New Roman';
ax.LineWidth = 1.2;
ax.Box = 'on';

grid on;

% ===== 缩小左右留白 =====
xlim([0.7 5.3]);

% ===== 设置左右坐标轴颜色 =====
ax.XColor = 'k';
ax.YAxis(1).Color = 'k';
ax.YAxis(2).Color = rightColor;

%% 图例
yyaxis left

lgd = legend([b, p], ...
    {'Triggering events', 'Utilization $R_c$'}, ...
    'Interpreter','latex', ...
    'Location','northwest', ...
    'Orientation','horizontal');

lgd.FontSize = 14;
lgd.Box = 'on';

%% 保存图片（可选）
% exportgraphics(gcf,'AUV_figure.png','Resolution',600);
