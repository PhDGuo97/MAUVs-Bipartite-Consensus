
%% ==========================================
% Event-triggered control-update reduction
% Blue bars + Orange line + Hollow circles
% ==========================================

clc;
close all





%% ==========================================
% Event-triggering counts and utilization
% Blue bars + Orange line (dual Y axes)
% ==========================================

% clc;

%% 1. Data
AUV = 1:5;

% Event-triggering counts
N_event = [337 350 348 335 326];

% Reference periodic updates
T_sim = 10;
h = 0.01;
N_total = T_sim/h;

% Utilization (%)
Ru =  N_event/N_total*100;

%% 2. Create figure
fig = figure('Color','w', ...
    'Position',[300 200 700 480]);

%% 3. Left Y-axis: event counts
yyaxis left

b = bar(AUV,N_event,0.60, ...
    'FaceColor',[0 0.4470 0.7410], ...
    'EdgeColor','k', ...
    'LineWidth',0.8);

ylabel('Number of triggering events', ...
    'FontName','Times New Roman', ...
    'FontSize',13);

ylim([0 450]);
yticks(0:50:450);

% Display event counts
for i = 1:5
    text(AUV(i),N_event(i)+12, ...
        sprintf('%d',N_event(i)), ...
        'HorizontalAlignment','center', ...
        'FontName','Times New Roman', ...
        'FontSize',11, ...
        'FontWeight','bold');
end

%% 4. Right Y-axis: utilization
yyaxis right
hold on;

p = plot(AUV,Ru,'-o', ...
    'Color',[0.8500 0.3250 0.0980], ...
    'LineWidth',1.8, ...
    'MarkerSize',7, ...
    'MarkerFaceColor','w', ...
    'MarkerEdgeColor',[0.8500 0.3250 0.0980]);

ylabel('Control-update utilization (%)', ...
    'FontName','Times New Roman', ...
    'FontSize',13);

ylim([0 45]);
yticks(0:5:45);

% Display utilization labels
for i = 1:5
    text(AUV(i),Ru(i)+1.1, ...
        sprintf('%.1f%%',Ru(i)), ...
        'HorizontalAlignment','center', ...
        'FontName','Times New Roman', ...
        'FontSize',14, ...
        'FontWeight','bold');
end

%% 5. Axes formatting
ax = gca;

ax.XTick = AUV;
ax.XTickLabel = ...
    {'AUV1','AUV2','AUV3','AUV4','AUV5'};

xlim([0.5 5.5]);

ax.FontName = 'Times New Roman';
ax.FontSize = 14;
ax.LineWidth = 1;
ax.TickDir = 'in';
ax.Box = 'on';

% Set both Y axes black
ax.YAxis(1).Color = 'k';
ax.YAxis(2).Color = 'k';

grid on;

%% 6. Legend
legend([b p], ...
    {'Triggering events','Utilization $R_c$'}, ...
    'Interpreter','latex', ...
    'Location','northwest', ...
    'FontSize',10);

%% 7. Export figure
set(fig,'PaperPositionMode','auto');

print(fig,'Event_Count_Utilization.png', ...
    '-dpng','-r600');

print(fig,'Event_Count_Utilization.pdf', ...
    '-dpdf','-painters');

%% 8. Display results
fprintf('\n===== Event Triggering Statistics =====\n');

for i = 1:5
    fprintf('AUV%d: Events = %d, Utilization = %.2f%%\n', ...
        i,N_event(i),Ru(i));
end

fprintf('Average utilization = %.2f%%\n',mean(Ru));
fprintf('Average reduction = %.2f%%\n',100-mean(Ru));



%% 数据
x_labels = {'AUV1','AUV2','AUV3','AUV4','AUV5'};
trigger_events = [337, 350, 348, 335, 326];
utilization = [66.3, 65.0, 65.2, 66.5, 67.4];

x = 1:length(x_labels);

%% 画图
figure('Color','w','Position',[200 200 900 550]);

% 左坐标轴：柱状图
yyaxis left
b = bar(x, trigger_events, 0.6, ...
    'FaceColor',[0.75 0.75 0.75], ...
    'EdgeColor','k', ...
    'LineWidth',1.2);
ylabel('Number of triggering events', 'FontSize', 16, 'FontName', 'Times New Roman');
ylim([0 450]);
yticks(0:50:450);

% 在柱顶标注触发次数
for i = 1:length(trigger_events)
    text(x(i), trigger_events(i)+8, num2str(trigger_events(i)), ...
        'HorizontalAlignment','center', ...
        'VerticalAlignment','bottom', ...
        'FontSize',16, ...
        'FontWeight','bold', ...
        'FontName','Times New Roman');
end

%% 右坐标轴：折线图
yyaxis right
p = plot(x, utilization, '-o', ...
    'Color', [0.8500 0.3250 0.0980], ...
    'LineWidth', 2.2, ...
    'MarkerSize', 10, ...
    'MarkerFaceColor', 'w', ...
    'MarkerEdgeColor', [0.8500 0.3250 0.0980]);
ylabel('Control-update utilization (%)', ...
    'FontSize',16, ...
    'Color',[0.8500 0.3250 0.0980], ...
    'FontName', 'Times New Roman');

% ===== 这里是修正后的右边坐标 =====
ylim([60 70]);              % 建议范围
yticks(60:2:70);            % 可按需修改为 60:1:70

% 在线附近标注百分比
for i = 1:length(utilization)
    text(x(i), utilization(i)-0.9, sprintf('%.1f%%', utilization(i)), ...
        'HorizontalAlignment','center', ...
        'VerticalAlignment','top', ...
        'FontSize',16, ...
        'FontWeight','bold', ...
        'Color',[0.8500 0.3250 0.0980], ...
        'FontName','Times New Roman');
end

%% 坐标轴与网格设置
ax = gca;
ax.XTick = x;
ax.XTickLabel = x_labels;
ax.FontSize = 16;
ax.FontName = 'Times New Roman';
ax.LineWidth = 1.2;
ax.Box = 'on';
ax.XColor = 'k';
ax.YColor = 'k';  % 左轴颜色
grid on;
ax.GridLineStyle = '-';
ax.GridColor = [0.8 0.8 0.8];
ax.GridAlpha = 1;

%% 图例
yyaxis left
lgd = legend([b, p], {'Triggering events', 'Utilization $R_c$'}, ...
    'Interpreter','latex', ...
    'Location','northwest', ...
    'Orientation','horizontal');
lgd.FontSize = 14;
lgd.Box = 'on';

%% 若需要保存图片
% exportgraphics(gcf,'redraw_figure.png','Resolution',300);



%% 数据
x_labels = {'AUV1','AUV2','AUV3','AUV4','AUV5'};
trigger_events = [337, 350, 348, 335, 326];
utilization = [66.3, 65.0, 65.2, 66.5, 67.4];

x = 1:length(x_labels);

%% 颜色设置
leftColor  = [0 0.4470 0.7410];      % 蓝色
rightColor = [0.8500 0.3250 0.0980]; % 橙色

%% 画图
figure('Color','w','Position',[200 200 900 550]);

% 左坐标轴：柱状图
yyaxis left
b = bar(x, trigger_events, 0.6, ...
    'FaceColor',[0.75 0.75 0.75], ...
    'EdgeColor','k', ...
    'LineWidth',1.2);
ylabel('Number of triggering events', ...
    'FontSize', 16, ...
    'FontName', 'Times New Roman', ...
    'Color', leftColor);
ylim([0 450]);
yticks(0:50:450);

% 在柱顶标注触发次数
for i = 1:length(trigger_events)
    text(x(i), trigger_events(i)+8, num2str(trigger_events(i)), ...
        'HorizontalAlignment','center', ...
        'VerticalAlignment','bottom', ...
        'FontSize',16, ...
        'FontWeight','bold', ...
        'FontName','Times New Roman');
end

%% 右坐标轴：折线图
yyaxis right
p = plot(x, utilization, '-o', ...
    'Color', rightColor, ...
    'LineWidth', 2.2, ...
    'MarkerSize', 10, ...
    'MarkerFaceColor', 'w', ...
    'MarkerEdgeColor', rightColor);
ylabel('Control-update utilization (%)', ...
    'FontSize',16, ...
    'Color', rightColor, ...
    'FontName', 'Times New Roman');

% ===== 这里是修正后的右边坐标 =====
ylim([60 70]);              % 建议范围
yticks(60:2:70);            % 可按需修改为 60:1:70

% 在线附近标注百分比
for i = 1:length(utilization)
    text(x(i), utilization(i)-0.9, sprintf('%.1f%%', utilization(i)), ...
        'HorizontalAlignment','center', ...
        'VerticalAlignment','top', ...
        'FontSize',16, ...
        'FontWeight','bold', ...
        'Color', rightColor, ...
        'FontName','Times New Roman');
end

%% 坐标轴与网格设置
ax = gca;
ax.XTick = x;
ax.XTickLabel = x_labels;
ax.FontSize = 16;
ax.FontName = 'Times New Roman';
ax.LineWidth = 1.2;
ax.Box = 'on';
ax.XColor = 'k';

% 左右坐标轴分别设置颜色
ax.YAxis(1).Color = leftColor;
ax.YAxis(2).Color = rightColor;

grid on;
ax.GridLineStyle = '-';
ax.GridColor = [0.8 0.8 0.8];
ax.GridAlpha = 1;

%% 图例
yyaxis left
lgd = legend([b, p], {'Triggering events', 'Utilization $R_c$'}, ...
    'Interpreter','latex', ...
    'Location','northwest', ...
    'Orientation','horizontal');
lgd.FontSize = 14;
lgd.Box = 'on';

%% 若需要保存图片
% exportgraphics(gcf,'redraw_figure.png','Resolution',300);




%% ================= 1. 数据 =================
x_labels = {'AUV1','AUV2','AUV3','AUV4','AUV5'};
trigger_events = [337, 350, 348, 335, 326];
utilization = [66.3, 65.0, 65.2, 66.5, 67.4];

x = 1:length(x_labels);

%% ================= 2. 颜色设置 =================
leftColor  = [0 0.4470 0.7410];       % 蓝色
rightColor = [0.8500 0.3250 0.0980]; % 橙色
barColor   = [0.75 0.75 0.75];        % 灰色

%% ================= 3. 创建画布 =================
fig = figure('Color','w', ...
    'Position',[200 200 850 500]);

%% ================= 4. 左坐标轴：柱状图 =================
yyaxis left

b = bar(x, trigger_events, 0.8, ...
    'FaceColor',barColor, ...
    'EdgeColor','k', ...
    'LineWidth',1.5);

ylabel('Number of triggering events', ...
    'FontSize',16, ...
    'FontName','Times New Roman', ...
    'Color',leftColor);

ylim([0 450]);
yticks(0:50:450);

% 柱顶标注触发次数
for i = 1:length(trigger_events)
    text(x(i), trigger_events(i)+8, ...
        num2str(trigger_events(i)), ...
        'HorizontalAlignment','center', ...
        'VerticalAlignment','bottom', ...
        'FontSize',16, ...
        'FontWeight','bold', ...
        'FontName','Times New Roman', ...
        'Color','k');
end

%% ================= 5. 右坐标轴：折线图 =================
yyaxis right

p = plot(x, utilization, '-o', ...
    'Color',rightColor, ...
    'LineWidth',2.2, ...
    'MarkerSize',9, ...
    'MarkerFaceColor','w', ...
    'MarkerEdgeColor',rightColor);

ylabel('Control-update utilization (%)', ...
    'FontSize',16, ...
    'Color',rightColor, ...
    'FontName','Times New Roman');

ylim([60 70]);
yticks(60:2:70);

% 百分比标注
for i = 1:length(utilization)
    text(x(i), utilization(i)-0.9, ...
        sprintf('%.1f%%',utilization(i)), ...
        'HorizontalAlignment','center', ...
        'VerticalAlignment','top', ...
        'FontSize',15, ...
        'FontWeight','bold', ...
        'Color',rightColor, ...
        'FontName','Times New Roman');
end

%% ================= 6. 坐标轴设置 =================
ax = gca;

ax.XTick = x;
ax.XTickLabel = x_labels;

% 缩小左右留白
xlim([0.48 5.52]);

ax.FontSize = 16;
ax.FontName = 'Times New Roman';
ax.LineWidth = 1.3;
ax.Box = 'on';

% 横坐标黑色
ax.XColor = 'k';

% 左侧蓝色，右侧橙色
ax.YAxis(1).Color = leftColor;
ax.YAxis(2).Color = rightColor;

% 刻度朝内
ax.TickDir = 'in';

% 网格线
grid on;
ax.GridLineStyle = '-';
ax.GridColor = [0.8 0.8 0.8];
ax.GridAlpha = 0.6;
ax.Layer = 'top';

%% ================= 7. 图例 =================
yyaxis left

lgd = legend([b,p], ...
    {'Triggering events','Utilization $R_c$'}, ...
    'Interpreter','latex', ...
    'Location','northwest', ...
    'Orientation','horizontal');

lgd.FontSize = 14;
lgd.Box = 'on';

%% ================= 8. 高清导出 =================
exportgraphics(fig,'AUV_optimized.png', ...
    'Resolution',600);

exportgraphics(fig,'AUV_optimized.pdf', ...
    'ContentType','vector');
