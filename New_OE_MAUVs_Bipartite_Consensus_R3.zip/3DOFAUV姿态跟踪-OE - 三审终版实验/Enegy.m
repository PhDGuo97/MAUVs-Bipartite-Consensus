
clc 
close all

input=out.input;
t=out.t1;
%% 提取15个控制输入

u11 = input(:,1);   u12 = input(:,2);   u13 = input(:,3);
u21 = input(:,4);   u22 = input(:,5);   u23 = input(:,6);
u31 = input(:,7);   u32 = input(:,8);   u33 = input(:,9);
u41 = input(:,10);  u42 = input(:,11);  u43 = input(:,12);
u51 = input(:,13);  u52 = input(:,14);  u53 = input(:,15);

%% 计算各通道控制能耗

E11 = trapz(t,u11.^2);
E12 = trapz(t,u12.^2);
E13 = trapz(t,u13.^2);

E21 = trapz(t,u21.^2);
E22 = trapz(t,u22.^2);
E23 = trapz(t,u23.^2);

E31 = trapz(t,u31.^2);
E32 = trapz(t,u32.^2);
E33 = trapz(t,u33.^2);

E41 = trapz(t,u41.^2);
E42 = trapz(t,u42.^2);
E43 = trapz(t,u43.^2);

E51 = trapz(t,u51.^2);
E52 = trapz(t,u52.^2);
E53 = trapz(t,u53.^2);

EAUV1 = E11 + E12 + E13;
EAUV2 = E21 + E22 + E23;
EAUV3 = E31 + E32 + E33;
EAUV4 = E41 + E42 + E43;
EAUV5 = E51 + E52 + E53;

fprintf('\n=========== Control Energy ===========\n');

fprintf('AUV1: %.6f\n',EAUV1);
fprintf('AUV2: %.6f\n',EAUV2);
fprintf('AUV3: %.6f\n',EAUV3);
fprintf('AUV4: %.6f\n',EAUV4);
fprintf('AUV5: %.6f\n',EAUV5);

fprintf('======================================\n');

Energy_Total = [
74508334.310817
507615113.336681
312850821.076845
246684143.338668
198095588.345987
];

mean(Energy_Total)



%% ===== Control Effort of Five AUVs =====
% input: Simulink exported data (66 channels)
% First 15 channels: control inputs of 5 AUVs

%% Step 1: Extract simulation data

if isa(input, 'timeseries')

    % Timeseries format
    t_data = input.Time;
    U_data = input.Data;

elseif isstruct(input)

    % Structure With Time format
    t_data = input.time;
    U_data = input.signals.values;

elseif isnumeric(input)

    % Numeric matrix format
    U_data = input;

    % Use the time vector in workspace
    if exist('tout','var')
        t_data = tout;
    elseif exist('t','var')
        t_data = t;
    else
        error('Time vector t or tout was not found.');
    end

else
    error('Unsupported input data type.');
end

%% Step 2: Convert data dimensions

t_data = t_data(:);
U_data = squeeze(U_data);

% Convert U_data to N x 66
if size(U_data,1) == length(t_data)

    U_all = U_data;

elseif size(U_data,2) == length(t_data)

    U_all = U_data';

else
    error('Time and input data dimensions do not match.');
end

% Check channel number
if size(U_all,2) < 15
    error('Input data contains fewer than 15 channels.');
end

%% Step 3: Extract 15 control inputs

U = U_all(:,1:15);

%% Step 4: Calculate Control Effort

E_u = zeros(5,1);

for i = 1:5

    % Three input channels for the i-th AUV
    ui = U(:,3*i-2:3*i);

    % Squared Euclidean norm
    ui_squared = sum(ui.^2,2);

    % Numerical integration
    E_u(i) = trapz(t_data,ui_squared);

end

%% Step 5: Total and average effort

E_total = sum(E_u);
E_average = mean(E_u);

%% Step 6: Display results

fprintf('\n========== Control Effort ==========\n');

for i = 1:5
    fprintf('AUV %d: %.6e\n',i,E_u(i));
end

fprintf('------------------------------------\n');
fprintf('Total   = %.6e\n',E_total);
fprintf('Average = %.6e\n',E_average);

%% Step 7: Save results

AUV = (1:5)';

Result = table(AUV,E_u, ...
    'VariableNames',{'AUV','ControlEffort'});

disp(Result);

writetable(Result,'ControlEffort_Results.xlsx');

Energy_Total_2 = [
     1.5292e+07  
     1.5417e+08  
     1.6669e+07  
     1.226e+07  
     2.6522e+07  
];

mean(Energy_Total_2)