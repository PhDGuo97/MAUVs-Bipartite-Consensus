function [sys,x0,str,ts,simStateCompliance] = ctrl2(t,x,u,flag)
%SFUNTMPL General MATLAB S-Function Template
%   With MATLAB S-functions, you can define you own ordinary differential
%   equations (ODEs), discrete system equations, and/or just about
%   any type of algorithm to be used within a Simulrnk block diagram.
%
%   The general form of an MATLAB S-function syntax is:
%       [SYS,X0,STR,TS,SIMSTATECOMPLIANCE] = SFUNC(T,X,U,FLAG,P1,...,Pn)
%
%   What is returned by SFUNC at a given point in time, T, depends on the
%   value of the FLAG, the current state vector, X, and the current
%   input vector, U.
%
%   FLAG   RESULT             DESCRIPTION
%   -----  ------             --------------------------------------------
%   0      [SIZES,X0,STR,TS]  Initialization, return system sizes in SYS,
%                             initial state in X0, state ordering strings
%                             in STR, and sample times in TS.
%   1      DX                 Return continuous state derivatives in SYS.
%   2      DS                 Update discrete states SYS = X(n+1)
%   3      Y                  Return outputs in SYS.
%   4      TNEXT              Return next time hit for variable step sample
%                             time in SYS.
%   5                         Reserved for future (root finding).
%   9      []                 Termination, perform any cleanup SYS=[].
%
%
%   The state vectors, X and X0 consists of continuous states followed
%   by discrete states.
%
%   Optional parameters, P1,...,Pn can be provided to the S-function and
%   used during any FLAG operation.
%
%   When SFUNC is called with FLAG = 0, the following information
%   should be returned:
%
%      SYS(1) = Number of continuous states.
%      SYS(2) = Number of discrete states.
%      SYS(3) = Number of outputs.
%      SYS(4) = Number of inputs.
%               Any of the first four elements in SYS can be specified
%               as -1 indicating that they are dynamically sized. The
%               actual length for all other flags will be equal to the
%               length of the input, U.
%      SYS(5) = Reserved for root finding. Must be zero.
%      SYS(6) = Direct feedthrough flag (1=yes, 0=no). The s-function
%               has direct feedthrough if U is used during the FLAG=3
%               call. Setting this to 0 is akin to making a promise that
%               U will not be used during FLAG=3. If you break the promise
%               then unpredictable results will occur.
%      SYS(7) = Number of sample times. This is the number of rows in TS.
%
%
%      X0     = Initial state conditions or [] if no states.
%
%      STR    = State ordering strings which is generally specified as [].
%
%      TS     = An m-by-2 matrix containing the sample time
%               (period, offset) information. Where m = number of sample
%               times. The ordering of the sample times must be:
%
%               TS = [0      0,      : Continuous sample time.
%                     0      1,      : Continuous, but fixed in minor step
%                                      sample time.
%                     PERIOD OFFSET, : Discrete sample time where
%                                      PERIOD > 0 & OFFSET < PERIOD.
%                     -2     0];     : Variable step discrete sample time
%                                      where FLAG=4 is used to get time of
%                                      next hit.
%
%               There can be more than one sample time providing
%               they are ordered such that they are monotonically
%               increasing. Only the needed sample times should be
%               specified in TS. When specifying more than one
%               sample time, you must check for sample hits explicitly by
%               seeing if
%                  abs(round((T-OFFSET)/PERIOD) - (T-OFFSET)/PERIOD)
%               is within a specified tolerance, generally 1e-8. This
%               tolerance is dependent upon your model's sampling times
%               and simulation time.
%
%               You can also specify that the sample time of the S-function
%               is inherited from the driving block. For functions which
%               change during minor steps, this is done by
%               specifying SYS(7) = 1 and TS = [-1 0]. For functions which
%               are held during minor steps, this is done by specifying
%               SYS(7) = 1 and TS = [-1 1].
%
%      SIMSTATECOMPLIANCE = Specifices how to handle this block when saving and
%                           restoring the complete simulation state of the
%                           model. The allowed values are: 'DefaultSimState',
%                           'HasNoSimState' or 'DisallowSimState'. If this value
%                           is not speficified, then the block's compliance with
%                           simState feature is set to 'UknownSimState'.


%   Copyright 1990-2010 The MathWorks, Inc.

%
% The following outlines the general structure of an S-function.
%
switch flag,

  %%%%%%%%%%%%%%%%%%
  % Initialization %
  %%%%%%%%%%%%%%%%%%
  case 0,
    [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes;

  %%%%%%%%%%%%%%%
  % Derivatives %
  %%%%%%%%%%%%%%%
  case 1,
    sys=mdlDerivatives(t,x,u);

  %%%%%%%%%%
  % Update %
  %%%%%%%%%%
  case 2,
    sys=mdlUpdate(t,x,u);

  %%%%%%%%%%%
  % Outputs %
  %%%%%%%%%%%
  case 3,
    sys=mdlOutputs(t,x,u);

  %%%%%%%%%%%%%%%%%%%%%%%
  % GetTimeOfNextVarHit %
  %%%%%%%%%%%%%%%%%%%%%%%
  case 4,
    sys=mdlGetTimeOfNextVarHit(t,x,u);

  %%%%%%%%%%%%%
  % Terminate %
  %%%%%%%%%%%%%
  case 9,
    sys=mdlTerminate(t,x,u);

  %%%%%%%%%%%%%%%%%%%%
  % Unexpected flags %
  %%%%%%%%%%%%%%%%%%%%
  otherwise
    DAStudio.error('Simulink:blocks:unhandledFlag', num2str(flag));

end

% end sfuntmpl

%
%=============================================================================
% mdlInitializeSizes
% Return the sizes, initial conditions, and sample times for the S-function.
%=============================================================================
%
function [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes

%
% call simsizes for a sizes structure, fill it in and convert it to a
% sizes array.
%
% Note that in this example, the values are hard coded.  This is not a
% recommended practice as the characteristics of the block are typically
% defined by the S-function parameters.
%
sizes = simsizes;

sizes.NumContStates  = 15;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 45+15+6;
sizes.NumInputs      = 30+15;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;   % at least one sample time is needed

sys = simsizes(sizes);

%
% initialize the initial conditions
%
x0  = [0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];

%
% str is always an empty matrix
%
str = [];

%
% initialize the array of sample times
%
ts  = [0 0];

% Specify the block simStateCompliance. The allowed values are:
%    'UnknownSimState', < The default setting; warn and assume DefaultSimState
%    'DefaultSimState', < Same sim state as a built-in block
%    'HasNoSimState',   < No sim state
%    'DisallowSimState' < Error out when saving or restoring the model sim state
simStateCompliance = 'UnknownSimState';

% end mdlInitializeSizes

%
%=============================================================================
% mdlDerivatives
% Return the derivatives for the continuous states.
%=============================================================================
%
function sys=mdlDerivatives(t,x,u)
global s_1 ;
global s_2 ;
global s_3 ;
global s_4 ;
global s_5 ;
sys = [sign(s_1); sign(s_2); sign(s_3); sign(s_4); sign(s_5)];


% end mdlDerivatives

%
%=============================================================================
% mdlUpdate
% Handle discrete state updates, sample time hits, and major time step
% requirements.
%=============================================================================
%
function sys=mdlUpdate(t,x,u)

sys = [];
% end mdlUpdate

%
%=============================================================================
% mdlOutputs
% Return the block outputs.
%=============================================================================
%
function sys=mdlOutputs(t,x,u)
% global u_1;
% global u_2;
% global u_3;
% global u_4;
% global u_5;

global s_1 ;
global s_2 ;
global s_3 ;
global s_4 ;
global s_5 ;
% global j ;
% global hate1 ;
% global hate2 ;
% global hate3 ;
% global hate4 ;
% global hate5;

% --- Safe initialization and NaN recovery ---

if isempty(s_1) || any(isnan(s_1)), s_1 = zeros(3,1); end
if isempty(s_2) || any(isnan(s_2)), s_2 = zeros(3,1); end
if isempty(s_3) || any(isnan(s_3)), s_3 = zeros(3,1); end
if isempty(s_4) || any(isnan(s_4)), s_4 = zeros(3,1); end
if isempty(s_5) || any(isnan(s_5)), s_5 = zeros(3,1); end

% if isempty(hate1) || any(isnan(hate1)), hate1 = zeros(3,1); end
% if isempty(hate2) || any(isnan(hate2)), hate2 = zeros(3,1); end
% if isempty(hate3) || any(isnan(hate3)), hate3 = zeros(3,1); end
% if isempty(hate4) || any(isnan(hate4)), hate4 = zeros(3,1); end
% if isempty(hate5) || any(isnan(hate5)), hate5 = zeros(3,1); end
% 

%以入弧计算
aij=[0 2 0 0 0;
     1 0 0 0 -1;
     -2 0 0 0 1;
     0 0 2 0 0;
     0 0 0 3 0];
%与领导者之间的通信关系
 b=[2 0 0 0 0];

 d=[1 1 -1 -1 -1];


% 无人机的姿态以及角速度
x1_1=u(10-9:12-9);
x2_1=u(13-9:15-9);
x1_2=u(16-9:18-9);
x2_2=u(19-9:21-9);
x1_3=u(22-9:24-9);
x2_3=u(25-9:27-9);
x1_4=u(28-9:30-9);
x2_4=u(31-9:33-9);
x1_5=u(34-9:36-9);
x2_5=u(37-9:39-9);


% 领导者的参考信号
x0t=[sin(t);cos(t);2];
v0t=[cos(t);-sin(t);0];
u0=[-sin(t);-cos(t);0];

%原文公式8，得到的是MAS的资质误差变量
[ext1, ext2, ext3, ext4, ext5] = eix0(x1_1,x1_2,x1_3,x1_4,x1_5,x0t);
[evt1, evt2, evt3, evt4, evt5] = eiv0(x2_1,x2_2,x2_3,x2_4,x2_5,v0t);

%auxiliaries errors 基于两个时变函数的辅助误差向量
e1=ext1';
e2=ext2';
e3=ext3';
e4=ext4';
e5=ext5';

%上下十个变量 分别计算MAS的综合分组一致误差，原文方程10
de1=evt1';
de2=evt2';
de3=evt3';
de4=evt4';
de5=evt5';

fai_1=x1_1(1);
th_1=x1_1(2);
fai_2=x1_2(1);
th_2=x1_2(2);
fai_3=x1_3(1);
th_3=x1_3(2);
fai_4=x1_4(1);
th_4=x1_4(2);
fai_5=x1_5(1);
th_5=x1_5(2);

%----------------------------------------------------------------------------
[Fai_1, dFai_1, M_1, sk_1, g_1]=get_all_matrix(th_1, fai_1, x2_1);
c_1=-M_1*pinv(dFai_1)*Fai_1-Fai_1'*sk_1*Fai_1;
f_1=-M_1^(-1)*(c_1*x2_1);
%----------------------------------------------------------------------------
[Fai_2, dFai_2, M_2, sk_2, g_2]=get_all_matrix(th_2, fai_2, x2_2);
c_2=-M_2*pinv(dFai_2)*Fai_2-Fai_2'*sk_2*Fai_2;
f_2=-M_2^(-1)*(c_2*x2_2);
%----------------------------------------------------------------------------
[Fai_3, dFai_3, M_3, sk_3, g_3]=get_all_matrix(th_3, fai_3, x2_3);
c_3=-M_3*pinv(dFai_3)*Fai_3-Fai_3'*sk_3*Fai_3;
f_3=-M_3^(-1)*(c_3*x2_3);
%----------------------------------------------------------------------------
[Fai_4, dFai_4, M_4, sk_4, g_4]=get_all_matrix(th_4, fai_4, x2_4);
c_4=-M_4*pinv(dFai_4)*Fai_4-Fai_4'*sk_4*Fai_4;
f_4=-M_4^(-1)*(c_4*x2_4);
%----------------------------------------------------------------------------
[Fai_5, dFai_5, M_5, sk_5, g_5]=get_all_matrix(th_5, fai_5, x2_5);
c_5=-M_5*pinv(dFai_5)*Fai_5-Fai_5'*sk_5*Fai_5;
f_5=-M_5^(-1)*(c_5*x2_5);
%----------------------------------------------------------------------------


lama=[2;2;2];


alpha1=1.5;
alpha2=1;
beta1=0.2;
beta2=0.2;
gama1=[0.6;0.6;0.6];
gama2=[1.2; 1.2; 1.2];
%J
Jxx=0.0552;
Jyy=0.0552;
Jzz=0.1104;
J=diag([Jxx,Jyy,Jzz]);
cimi_1=1.5; % 1.2

u_1 = u(31:33);
u_2 = u(34:36);
u_3 = u(37:39);
u_4 = u(40:42);
u_5 = u(43:45);

u_1_f=g_1*u_1+f_1;
u_2_f=g_2*u_2+f_2;
u_3_f=g_3*u_3+f_3;
u_4_f=g_4*u_4+f_4;
u_5_f=g_5*u_5+f_5;

s_1=de1+lama.*e1 + abs(e1).^(cimi_1).*sign(e1)+(alpha2*beta1)/(1+alpha2).*abs(e1+beta2*abs(e1).^(alpha1).*sign(e1)).^(1+1/alpha2).*sign(e1+abs(e1).^(alpha1).*sign(e1));
ds1=+lama.*de1+(cimi_1)*abs(e1).^((cimi_1)-1).*de1+beta1.*abs(e1+beta2.*abs(e1).^alpha1.*sign(e1)).^(1/alpha2).*(de1+alpha1*beta2.*abs(e1).^(alpha1-1).*de1);
s_2=de2+lama.*e2+abs(e2).^(cimi_1).*sign(e2)+(alpha2*beta1)/(1+alpha2).*abs(e2+beta2*abs(e2).^(alpha1).*sign(e2)).^(1+1/alpha2).*sign(e2+abs(e2).^(alpha1).*sign(e2));
ds2=+lama.*de2+(cimi_1)*abs(e2).^((cimi_1)-1).*de2+beta1.*abs(e2+beta2.*abs(e2).^alpha1.*sign(e2)).^(1/alpha2).*(de2+alpha1*beta2.*abs(e2).^(alpha1-1).*de2);
s_3=de3+lama.*e3 + abs(e3).^(cimi_1).*sign(e3)+(alpha2*beta1)/(1+alpha2).*abs(e3+beta2*abs(e3).^(alpha1).*sign(e3)).^(1+1/alpha2).*sign(e3+abs(e3).^(alpha1).*sign(e3));
ds3=+lama.*de3+(cimi_1)*abs(e3).^((cimi_1)-1).*de3+beta1.*abs(e3+beta2.*abs(e3).^alpha1.*sign(e3)).^(1/alpha2).*(de3+alpha1*beta2.*abs(e3).^(alpha1-1).*de3);
s_4=de4+lama.*e4 + abs(e4).^(cimi_1).*sign(e4)+(alpha2*beta1)/(1+alpha2).*abs(e4+beta2*abs(e4).^(alpha1).*sign(e4)).^(1+1/alpha2).*sign(e4+abs(e4).^(alpha1).*sign(e4));
ds4=+lama.*de4+(cimi_1)*abs(e4).^((cimi_1)-1).*de4+beta1.*abs(e4+beta2.*abs(e4).^alpha1.*sign(e4)).^(1/alpha2).*(de4+alpha1*beta2.*abs(e4).^(alpha1-1).*de4);
s_5=de5+lama.*e5 + abs(e5).^(cimi_1).*sign(e5)+(alpha2*beta1)/(1+alpha2).*abs(e5+beta2*abs(e5).^(alpha1).*sign(e5)).^(1+1/alpha2).*sign(e5+abs(e5).^(alpha1).*sign(e5));
ds5=+lama.*de5+(cimi_1)*abs(e5).^((cimi_1)-1).*de5+beta1.*abs(e5+beta2.*abs(e5).^alpha1.*sign(e5)).^(1/alpha2).*(de5+alpha1*beta2.*abs(e5).^(alpha1-1).*de5);



fai1 = 0.7;
fai2 = 10;
kesai = 0.1; 
fai0 = 10; 

if t < 2
    gain1 = fai1*t + fai2;
    gain2 = fai1*t + fai2;
    gain3 = fai1*t + fai2;
    gain4 = fai1*t + fai2;
    gain5 = fai1*t + 14;
else
    % --- 加入越界保护 ---
    eps_safe = 1e-1;   % 防止除以0
    denom1 = max(kesai - norm(s_1), eps_safe);
    denom2 = max(kesai - norm(s_2), eps_safe);
    denom3 = max(kesai - norm(s_3), eps_safe);
    denom4 = max(kesai - norm(s_4), eps_safe);
    denom5 = max(kesai - norm(s_5), eps_safe);

    gain1 = kesai * fai0 / denom1;
    gain2 = kesai * fai0 / denom2;
    gain3 = kesai * fai0 / denom3;
    gain4 = kesai * fai0 / denom4;
    gain5 = kesai * fai0 / denom5;
end

% 超螺旋算法
stwist1 = [x(1); x(2); x(3)];
stwist2 = [x(4); x(5); x(6)];
stwist3 = [x(7); x(8); x(9)];
stwist4 = [x(10); x(11); x(12)];
stwist5 = [x(13); x(14); x(15)];
yita = 5 ;


% 注释掉的控制率是可以运行的， 是不加障碍函数的
% % uc1=- g_1^(-1)*f_1+g_1^(-1)*(2+2)^(-1)*(aij(1,1)*u_1_f+aij(1,2)*u_2_f+aij(1,3)*u_3_f+aij(1,4)*u_4_f+aij(1,5)*u_5_f-ds1-10.*(abs(s_1).^(gama1)).*sign(s_1)-7.*stwist1);
% uc1=- g_1^(-1)*f_1+g_1^(-1)*(2+2)^(-1)*(aij(1,1)*u_1_f+aij(1,2)*u_2_f+aij(1,3)*u_3_f+aij(1,4)*u_4_f+aij(1,5)*u_5_f-ds1-gain1.*(abs(s_1).^(gama1)).*sign(s_1)-0.005*gain1^2.*stwist1);

%     % uc2=- g_2^(-1)*f_2+g_2^(-1)*(2+0)^(-1)*(aij(2,1)*u_1_f+aij(2,2)*u_2_f+aij(2,3)*u_3_f+aij(2,4)*u_4_f+aij(2,5)*u_5_f-ds2-10.*(abs(s_2).^(gama1)).*sign(s_2)-7.*stwist2);
%     uc2=- g_2^(-1)*f_2+g_2^(-1)*(2+0)^(-1)*(aij(2,1)*u_1_f+aij(2,2)*u_2_f+aij(2,3)*u_3_f+aij(2,4)*u_4_f+aij(2,5)*u_5_f-ds2-gain2.*(abs(s_2).^(gama1)).*sign(s_2)-0.005*gain2^2.*stwist2);
% 
%     % uc3=-g_3^(-1)*f_3+g_3^(-1)*(3+0)^(-1)*(aij(3,1)*u_1_f+aij(3,2)*u_2_f+aij(3,3)*u_3_f+aij(3,4)*u_4_f+aij(3,5)*u_5_f-ds3-10.*(abs(s_3).^(gama1)).*sign(s_3)-7.*stwist3);
%     uc3=-g_3^(-1)*f_3+g_3^(-1)*(3+0)^(-1)*(aij(3,1)*u_1_f+aij(3,2)*u_2_f+aij(3,3)*u_3_f+aij(3,4)*u_4_f+aij(3,5)*u_5_f-ds3-gain3.*(abs(s_3).^(gama1)).*sign(s_3)-0.005*gain3^2.*stwist3);
% 
%     % uc4=- g_4^(-1)*f_4+g_4^(-1)*(2+0)^(-1)*(aij(4,1)*u_1_f+aij(4,2)*u_2_f+aij(4,3)*u_3_f+aij(4,4)*u_4_f+aij(4,5)*u_5_f-ds4-10.*(abs(s_4).^(gama1)).*sign(s_4)-7.*stwist4);
%     uc4=- g_4^(-1)*f_4+g_4^(-1)*(2+0)^(-1)*(aij(4,1)*u_1_f+aij(4,2)*u_2_f+aij(4,3)*u_3_f+aij(4,4)*u_4_f+aij(4,5)*u_5_f-ds4-gain4.*(abs(s_4).^(gama1)).*sign(s_4)-0.005*gain4^2.*stwist4);
% 
%     hate5 = e5 ;
%     % uc5=- g_5^(-1)*f_5+g_5^(-1)*(3+0)^(-1)*(aij(5,1)*u_1_f+aij(5,2)*u_2_f+aij(5,3)*u_3_f+aij(5,4)*u_4_f+aij(5,5)*u_5_f-ds5-10.*(abs(s_5).^(gama1)).*sign(s_5)-7.*stwist5);
%     uc5=- g_5^(-1)*f_5+g_5^(-1)*(3+0)^(-1)*(aij(5,1)*u_1_f+aij(5,2)*u_2_f+aij(5,3)*u_3_f+aij(5,4)*u_4_f+aij(5,5)*u_5_f-ds5-10.*(abs(s_5).^(gama1)).*sign(s_5)-5.*stwist5);

uc1_cand =- g_1^(-1)*f_1+g_1^(-1)*(2+2)^(-1)*(aij(1,1)*u_1_f+aij(1,2)*u_2_f+aij(1,3)*u_3_f+aij(1,4)*u_4_f+aij(1,5)*u_5_f-ds1-gain1.*(abs(s_1).^(gama1)).*sign(s_1)-0.005*gain1^2.*stwist1);

uc2_cand = - g_2^(-1)*f_2 + g_2^(-1)*(2+0)^(-1)* ...
           (aij(2,1)*u_1_f + aij(2,2)*u_2_f + aij(2,3)*u_3_f + aij(2,4)*u_4_f + aij(2,5)*u_5_f ...
            - ds2 - gain2.*(abs(s_2).^(gama1)).*sign(s_2) - 0.005*gain2^2.*stwist2);

uc3_cand = - g_3^(-1)*f_3 + g_3^(-1)*(3+0)^(-1)* ...
           (aij(3,1)*u_1_f + aij(3,2)*u_2_f + aij(3,3)*u_3_f + aij(3,4)*u_4_f + aij(3,5)*u_5_f ...
            - ds3 - gain3.*(abs(s_3).^(gama1)).*sign(s_3) - 0.005*gain3^2.*stwist3);

uc4_cand = - g_4^(-1)*f_4 + g_4^(-1)*(2+0)^(-1)* ...
           (aij(4,1)*u_1_f + aij(4,2)*u_2_f + aij(4,3)*u_3_f + aij(4,4)*u_4_f + aij(4,5)*u_5_f ...
            - ds4 - gain4.*(abs(s_4).^(gama1)).*sign(s_4) - 0.005*gain4^2.*stwist4);

uc5_cand = - g_5^(-1)*f_5 + g_5^(-1)*(3+0)^(-1)* ...
           (aij(5,1)*u_1_f + aij(5,2)*u_2_f + aij(5,3)*u_3_f + aij(5,4)*u_4_f + aij(5,5)*u_5_f ...
            - ds5 - 10.*(abs(s_5).^(gama1)).*sign(s_5) - 5.*stwist5);

delta=0.05; sigma=1e-3;
pi1=norm(uc1_cand-u_1); th1=delta*norm(u_1)+sigma;
pi2=norm(uc2_cand-u_2); th2=delta*norm(u_2)+sigma;
pi3=norm(uc3_cand-u_3); th3=delta*norm(u_3)+sigma;
pi4=norm(uc4_cand-u_4); th4=delta*norm(u_4)+sigma;
pi5=norm(uc5_cand-u_5); th5=delta*norm(u_5)+sigma;

trig1=double(pi1>th1);
trig2=double(pi2>th2);
trig3=double(pi3>th3);
trig4=double(pi4>th4);
trig5=double(pi5>th5);
trigAny=double(trig1|trig2|trig3|trig4|trig5);

if trig1 
    uc1=uc1_cand; 
else
    uc1=u_1;
end
if trig2 
    uc2=uc2_cand; 
else
    uc2=u_2;
end
if trig3 
    uc3=uc3_cand; 
else
    uc3=u_3;
end
if trig4
    uc4=uc4_cand; 
else
    uc4=u_4;
end
if trig5 
    uc5=uc5_cand; 
else
    uc5=u_5;
end

% 控制输入
sys(1:3) = uc1;
sys(4:6) = uc2;
sys(7:9) = uc3;
sys(10:12) = uc4;
sys(13:15) = uc5;
% 滑模面
sys(16:18) = s_1;
sys(19:21) = s_2;
sys(22:24) = s_3;
sys(25:27) = s_4;
sys(28:30) = s_5;
% 一致性误差
sys(31:33) = e1;
sys(34:36) = e2;
sys(37:39) = e3;
sys(40:42) = e4;
sys(43:45) = e5;

sys(46:48) = de1;
sys(49:51) = de2;
sys(52:54) = de3;
sys(55:57) = de4;
sys(58:60) = de5;

trigAny = double(trig1 | trig2 | trig3 | trig4 | trig5);
sys(61) = trig1;
sys(62) = trig2;
sys(63) = trig3;
sys(64) = trig4;
sys(65) = trig5;
sys(66) = trigAny;

% sys(46) = gain1;
% sys(47) = gain2;
% sys(48) = gain3;
% sys(49) = gain4;
% sys(50) = gain5;
% end mdlOutputs

%
%=============================================================================
% mdlGetTimeOfNextVarHit
% Return the time of the next hit for this block.  Note that the result is
% absolute time.  Note that this function is only used when you specify a
% variable discrete-time sample time [-2 0] in the sample time array in
% mdlInitializeSizes.
%=============================================================================
%
function sys=mdlGetTimeOfNextVarHit(t,x,u)

sampleTime = 1;    %  Example, set the next hit to be one second later.
sys = t + sampleTime;

% end mdlGetTimeOfNextVarHit

%
%=============================================================================
% mdlTerminate
% Perform any end of simulation tasks.
%=============================================================================
%
function sys=mdlTerminate(t,x,u)

sys = [];

% end mdlTerminate
