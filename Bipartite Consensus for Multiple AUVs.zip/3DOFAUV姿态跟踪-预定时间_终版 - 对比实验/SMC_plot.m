close all;
input=out.input;
T=out.t1;
tri1(:,1) = input(:,31);
tri2(:,1) = input(:,34);
tri3(:,1) = input(:,37);
tri4(:,1) = input(:,40);
tri5(:,1) = input(:,43);

figure(1)
ax1 = subplot(2, 1, 1);
n1=size(tri1(:,1));
 TimeofFixed1=[];
 NumofFixed1=0;
 count1 = 0 ;
for i=1:n1-1
    if tri1(i,1)~= tri1(i+1,1)%找到不相同的两个触发时刻状态
        TimeofFixed1=[TimeofFixed1,T(i)];%存放对应的触发时刻
        NumofFixed1=NumofFixed1+1;
        count1 = count1 + 1;
    end
end
disp(count1);
t_interval=zeros(NumofFixed1-1,1);
t_interval(1)=TimeofFixed1(1);
for i=2:NumofFixed1-1
        t_interval(i)=TimeofFixed1(i)-TimeofFixed1(i-1);%作差算出事件间时间
end
stem(TimeofFixed1(1:NumofFixed1-1),t_interval,'o');
disp(mean(t_interval));
legend('AUV1');
set(gca, 'XTickLabel', []);  % 移除刻度标签
hold on;
ylabel({'$T_{i} $'},'interpreter','latex')

ax2 = subplot(2, 1, 2);
n2=size(tri2(:,1));
 TimeofFixed2=[];
 NumofFixed2=0;
 count2 = 0 ;
for i=1:n2-1
    if tri2(i,1)~= tri2(i+1,1)%找到不相同的两个触发时刻状态
        TimeofFixed2=[TimeofFixed2,T(i)];%存放对应的触发时刻
        NumofFixed2=NumofFixed2+1;
        count2 = count2 + 1 ; 
    end
end
disp(count2);
t_interval2=zeros(NumofFixed2-1,1);
t_interval2(1)=TimeofFixed2(1);
for i=2:NumofFixed2-1
        t_interval2(i)=TimeofFixed2(i)-TimeofFixed2(i-1);%作差算出事件间时间
end
stem(TimeofFixed2(1:NumofFixed2-1),t_interval2,'o');
legend('AUV2');
disp(mean(t_interval2));
%  axis([0 40 0 0.02]);
% set(gca,'YTick',0:0.01:0.05);
hold on;

% # 调整子图间距
set(ax1, 'Position', [0.1 0.55 0.8 0.4]);  % [左 下 宽 高]
set(ax2, 'Position', [0.1 0.1 0.8 0.4]);

% xlabel('Time(s)')
% ylabel({'$T_{i} $'},'interpreter','latex')


figure(2)
ax1 = subplot(3, 1, 1);
n1=size(tri3(:,1));
 TimeofFixed1=[];
 NumofFixed1=0;
 count1 = 0 ;
for i=1:n1-1
    if tri1(i,1)~= tri1(i+1,1)%找到不相同的两个触发时刻状态
        TimeofFixed1=[TimeofFixed1,T(i)];%存放对应的触发时刻
        NumofFixed1=NumofFixed1+1;
        count1 = count1 + 1;
    end
end
disp(count1);
t_interval=zeros(NumofFixed1-1,1);
t_interval(1)=TimeofFixed1(1);
for i=2:NumofFixed1-1
        t_interval(i)=TimeofFixed1(i)-TimeofFixed1(i-1);%作差算出事件间时间
end
stem(TimeofFixed1(1:NumofFixed1-1),t_interval,'o');
disp(mean(t_interval));
legend('AUV3');
set(gca, 'XTickLabel', []);  % 移除刻度标签
hold on;
% ylabel({'$T_{i} $'},'interpreter','latex')

ax2 = subplot(3, 1, 2);
n2=size(tri4(:,1));
 TimeofFixed2=[];
 NumofFixed2=0;
 count2 = 0 ;
for i=1:n2-1
    if tri2(i,1)~= tri2(i+1,1)%找到不相同的两个触发时刻状态
        TimeofFixed2=[TimeofFixed2,T(i)];%存放对应的触发时刻
        NumofFixed2=NumofFixed2+1;
        count2 = count2 + 1 ; 
    end
end
disp(count2);
t_interval2=zeros(NumofFixed2-1,1);
t_interval2(1)=TimeofFixed2(1);
for i=2:NumofFixed2-1
        t_interval2(i)=TimeofFixed2(i)-TimeofFixed2(i-1);%作差算出事件间时间
end
stem(TimeofFixed2(1:NumofFixed2-1),t_interval2,'o');
legend('AUV4');
disp(mean(t_interval2));
%  axis([0 40 0 0.02]);
% set(gca,'YTick',0:0.01:0.05);
hold on;

ax3 = subplot(3, 1, 3);
n2=size(tri5(:,1));
 TimeofFixed2=[];
 NumofFixed2=0;
 count2 = 0 ;
for i=1:n2-1
    if tri2(i,1)~= tri2(i+1,1)%找到不相同的两个触发时刻状态
        TimeofFixed2=[TimeofFixed2,T(i)];%存放对应的触发时刻
        NumofFixed2=NumofFixed2+1;
        count2 = count2 + 1 ; 
    end
end
disp(count2);
t_interval2=zeros(NumofFixed2-1,1);
t_interval2(1)=TimeofFixed2(1);
for i=2:NumofFixed2-1
        t_interval2(i)=TimeofFixed2(i)-TimeofFixed2(i-1);%作差算出事件间时间
end
stem(TimeofFixed2(1:NumofFixed2-1),t_interval2,'o');
legend('AUV5');
disp(mean(t_interval2));
%  axis([0 40 0 0.02]);
% set(gca,'YTick',0:0.01:0.05);
hold on;

% 调整子图间距和位置
vertical_gap = 0.06;  % 稍微增大垂直间距
height = (1 - 3*vertical_gap) / 3;  % 每个子图的高度（3个间隙）

% 设置位置 [left bottom width height]
set(ax1, 'Position', [0.15 0.70 0.75 height]);  % 底部位置调整
set(ax2, 'Position', [0.15 0.37 0.75 height]);  % 中间位置
set(ax3, 'Position', [0.15 0.04 0.75 height]);  % 底部位置
