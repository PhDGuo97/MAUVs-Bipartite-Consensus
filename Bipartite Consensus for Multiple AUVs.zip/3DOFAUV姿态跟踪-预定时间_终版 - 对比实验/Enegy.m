
clc 
close all

input=out.input;
t=out.t1;
%% 提取15个控制输入

u11 = input(:,1);   u12 = input(:,2);   u13 = input(:,3);
u21 = input(:,4);   u22 = input(:,5);   u23 = input(:,6);
u31 = input(:,7);   u32 = input(:,8);   u33 = input(:,9);
u41 = input(:,10);  u42 = input(:,11);  u43 = input(:,12);
u51 = input(:,13);  u52 = input(:,14);  u53 = input(:,15);

%% 计算各通道控制能耗

E11 = trapz(t,u11.^2);
E12 = trapz(t,u12.^2);
E13 = trapz(t,u13.^2);

E21 = trapz(t,u21.^2);
E22 = trapz(t,u22.^2);
E23 = trapz(t,u23.^2);

E31 = trapz(t,u31.^2);
E32 = trapz(t,u32.^2);
E33 = trapz(t,u33.^2);

E41 = trapz(t,u41.^2);
E42 = trapz(t,u42.^2);
E43 = trapz(t,u43.^2);

E51 = trapz(t,u51.^2);
E52 = trapz(t,u52.^2);
E53 = trapz(t,u53.^2);

EAUV1 = E11 + E12 + E13;
EAUV2 = E21 + E22 + E23;
EAUV3 = E31 + E32 + E33;
EAUV4 = E41 + E42 + E43;
EAUV5 = E51 + E52 + E53;

fprintf('\n=========== Control Energy ===========\n');

fprintf('AUV1: %.6f\n',EAUV1);
fprintf('AUV2: %.6f\n',EAUV2);
fprintf('AUV3: %.6f\n',EAUV3);
fprintf('AUV4: %.6f\n',EAUV4);
fprintf('AUV5: %.6f\n',EAUV5);

fprintf('======================================\n');

Energy_Total = [
74508334.310817
507615113.336681
312850821.076845
246684143.338668
198095588.345987
];

mean(Energy_Total)