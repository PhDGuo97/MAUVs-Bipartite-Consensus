function result = Sig(a, b)
    result = abs(a).^b.*sign(a);
end