clc 
close all



% input=out.input;
% e11 = input(:,31);
% e12 = input(:,32);
% e13 = input(:,33);
% e21 = input(:,34);
% e22 = input(:,35);
% e23 = input(:,36);
% e31 = input(:,37);
% e32 = input(:,38);
% e33 = input(:,39);
% e41 = input(:,40);
% e42 = input(:,41);
% e43 = input(:,42);
% e51 = input(:,43);
% e52 = input(:,44);
% e53 = input(:,45);
% 
% e1=[e11 e12 e13];
% e_norm_1 = sqrt(sum(e1.^2,2));
% RMSE_total_1 = sqrt(mean(sum(e_norm_1.^2,2)));
% fprintf('RMSE_total_1 = %.6f\n', RMSE_total_1);
% 
% RMSE11 = sqrt(mean(sum(e11.^2,2)));
% RMSE12 = sqrt(mean(sum(e12.^2,2)));
% RMSE13 = sqrt(mean(sum(e13.^2,2)));
% RMSE21 = sqrt(mean(sum(e21.^2,2)));
% RMSE22 = sqrt(mean(sum(e22.^2,2)));
% RMSE23 = sqrt(mean(sum(e23.^2,2)));
% RMSE31 = sqrt(mean(sum(e31.^2,2)));
% RMSE32 = sqrt(mean(sum(e32.^2,2)));
% RMSE33 = sqrt(mean(sum(e33.^2,2)));
% RMSE41 = sqrt(mean(sum(e41.^2,2)));
% RMSE42 = sqrt(mean(sum(e42.^2,2)));
% RMSE43 = sqrt(mean(sum(e43.^2,2)));
% RMSE51 = sqrt(mean(sum(e51.^2,2)));
% RMSE52 = sqrt(mean(sum(e52.^2,2)));
% RMSE53 = sqrt(mean(sum(e53.^2,2)));
% 
% fprintf('\n================ RMSE Results ================\n');
% 
% fprintf('RMSE11 = %.6f\n', RMSE11);
% fprintf('RMSE12 = %.6f\n', RMSE12);
% fprintf('RMSE13 = %.6f\n', RMSE13);
% 
% fprintf('RMSE21 = %.6f\n', RMSE21);
% fprintf('RMSE22 = %.6f\n', RMSE22);
% fprintf('RMSE23 = %.6f\n', RMSE23);
% 
% fprintf('RMSE31 = %.6f\n', RMSE31);
% fprintf('RMSE32 = %.6f\n', RMSE32);
% fprintf('RMSE33 = %.6f\n', RMSE33);
% 
% fprintf('RMSE41 = %.6f\n', RMSE41);
% fprintf('RMSE42 = %.6f\n', RMSE42);
% fprintf('RMSE43 = %.6f\n', RMSE43);
% 
% fprintf('RMSE51 = %.6f\n', RMSE51);
% fprintf('RMSE52 = %.6f\n', RMSE52);
% fprintf('RMSE53 = %.6f\n', RMSE53);
% 
% fprintf('==============================================\n');
u11 = input(:,1);
u12 = input(:,2);
u13 = input(:,3);
u21 = input(:,4);
u22 = input(:,5);

E11 = trapz(t,sum(u11.^2,2));
E12 = trapz(t,sum(u12.^2,2));
E13 = trapz(t,sum(u13.^2,2));
% E4 = trapz(t,sum(u4.^2,2));
% E5 = trapz(t,sum(u5.^2,2));

% Energy = [E1 E2 E3 E4 E5];
fprintf('AUV1 Energy = %.4f\n',E11);
fprintf('AUV2 Energy = %.4f\n',E12);
fprintf('AUV3 Energy = %.4f\n',E13);
fprintf('AUV4 Energy = %.4f\n',E4);
fprintf('AUV5 Energy = %.4f\n',E5);

RMSE = [
    RMSE11 RMSE12 RMSE13;
    RMSE21 RMSE22 RMSE23;
    RMSE31 RMSE32 RMSE33;
    RMSE41 RMSE42 RMSE43;
    RMSE51 RMSE52 RMSE53
];

disp('RMSE Matrix = ');
disp(RMSE);

figure('Color','w');
hold on

%% 分组柱状图
b = bar(RMSE,'grouped');

b(1).FaceColor = [0 0.4470 0.7410];
b(2).FaceColor = [0.8500 0.3250 0.0980];
b(3).FaceColor = [0.4660 0.6740 0.1880];

%% 获取柱中心位置
ngroups = size(RMSE,1);
nbars   = size(RMSE,2);

groupwidth = min(0.8, nbars/(nbars+1.5));

xpos = zeros(ngroups,nbars);

for k = 1:nbars
    xpos(:,k) = (1:ngroups) ...
        - groupwidth/2 ...
        + (2*k-1)*groupwidth/(2*nbars);
end

%% 折线图
plot(xpos(:,1),RMSE(:,1),'-o',...
    'LineWidth',2,...
    'MarkerSize',7,...
    'Color',[0 0.4470 0.7410]);

plot(xpos(:,2),RMSE(:,2),'-s',...
    'LineWidth',2,...
    'MarkerSize',7,...
    'Color',[0.8500 0.3250 0.0980]);

plot(xpos(:,3),RMSE(:,3),'-^',...
    'LineWidth',2,...
    'MarkerSize',7,...
    'Color',[0.4660 0.6740 0.1880]);

%% 数值标签
for i = 1:ngroups
    for j = 1:nbars
        text(xpos(i,j),...
             RMSE(i,j)+0.1,...
             sprintf('%.3f',RMSE(i,j)),...
             'HorizontalAlignment','center',...
             'FontSize',10,...
             'FontWeight','bold');
    end
end

%% 坐标轴设置
set(gca,...
    'FontSize',12,...
    'FontName','Times New Roman');

% xlabel('AUV Index','FontSize',13);
ylabel('RMSE','FontSize',13);

xticks(1:5);
xticklabels({'AUV1','AUV2','AUV3','AUV4','AUV5'});

legend({'RMSE-x','RMSE-y','RMSE-z'},...
       'Location','northwest');

grid on
box on

% ylim([0 0.42])

title('RMSE Comparison of Five AUVs');



figure
b = bar(RMSE,'grouped');

b(1).FaceColor = [0 0.447 0.741];
b(2).FaceColor = [0.850 0.325 0.098];
b(3).FaceColor = [0.466 0.674 0.188];

% xlabel('AUV Index')
ylabel('RMSE')

xticklabels({'AUV1','AUV2','AUV3','AUV4','AUV5'})

legend('x-axis','y-axis','z-axis')

grid on
box on

