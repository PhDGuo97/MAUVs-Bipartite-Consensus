function [sys,x0,str,ts] = eivt(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 3,
    sys=mdlOutputs(t,x,u);
case {1,2,4,9}
    sys=[];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 15;
sizes.NumInputs      = 39;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 0;
sys = simsizes(sizes);
x0  = [];
str = [];
ts  = [];
function sys=mdlOutputs(t,x,u)


vit1_1=[u(13);u(14);u(15)];
vit2_1=[u(19);u(20);u(21)];
vit3_1=[u(25);u(26);u(27)];
vit4_1=[u(31);u(32);u(33)];
vit5_1=[u(37);u(38);u(39)];

v0t=[u(4);u(5);u(6)];

[evt1, evt2, evt3, evt4, evt5] = eiv0(vit1_1,vit2_1,vit3_1,vit4_1,vit5_1,v0t);

sys(1:3)=evt1;
sys(4:6)=evt2;
sys(7:9)=evt3;
sys(10:12)=evt4;
sys(13:15)=evt5;







