
function [Fai, dFai, M, sk, g]= get_all_matrix(th, fai , x2)
%J
Jxx=0.0552;
Jyy=0.0552;
Jzz=0.1104;
J=diag([Jxx,Jyy,Jzz]);
%Fai
Fai=[1 0 -sin(th);
    0 cos(fai) sin(fai)*cos(th);
    0 -sin(fai) cos(fai)*cos(th)];
dFai=[0 0 -cos(th);
    0 -sin(fai) cos(fai)*cos(th)+sin(fai)*(-sin(th));
    0 -cos(fai) -sin(fai)*cos(th)-cos(fai)*sin(th)];
g=(J*Fai)^(-1);
%M
M=[Jxx 0 -Jxx*sin(th);
    0 Jyy*sin(fai)^2+Jzz*cos(fai)^2 (Jyy-Jzz)*cos(th)*cos(fai)*sin(fai);
    -Jxx*sin(th) (Jyy-Jzz)*cos(th)*cos(fai)*sin(fai) Jxx*sin(th)^2+cos(th)^2*(Jyy*sin(fai)^2+Jzz*cos(fai)^2)];
%sk
bata=J*Fai*x2;
sk=[0 -bata(3) bata(2);
    bata(3) 0 -bata(1);
    -bata(2) bata(1) 0];
end 