function [sys,x0,str,ts] = eixt(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 3,
    sys=mdlOutputs(t,x,u);
case {1,2,4,9}
    sys=[];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 15;
sizes.NumInputs      = 39;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 0;
sys = simsizes(sizes);
x0  = [];
str = [];
ts  = [];
function sys=mdlOutputs(t,x,u)


xit1_1=[u(10);u(11);u(12)];
xit2_1=[u(16);u(17);u(18)];
xit3_1=[u(22);u(23);u(24)];
xit4_1=[u(28);u(29);u(30)];
xit5_1=[u(34);u(35);u(36)];

x0t=[u(1);u(2);u(3)];

%原文公式8，得到的是MAS的资质误差变量
[ext1, ext2, ext3, ext4, ext5] = eix0(xit1_1,xit2_1,xit3_1,xit4_1,xit5_1,x0t);

sys(1:3)=ext1;
sys(4:6)=ext2;
sys(7:9)=ext3;
sys(10:12)=ext4;
sys(13:15)=ext5;







