function [sys,x0,str,ts,simStateCompliance] = plant_AUV(t,x,u,flag)

switch flag,
  case 0,
    [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes;
  case 1,
    sys=mdlDerivatives(t,x,u);
  case 2,
    sys=mdlUpdate(t,x,u);
  case 3,
    sys=mdlOutputs(t,x,u);
  case 4,
    sys=mdlGetTimeOfNextVarHit(t,x,u);
  case 9,
    sys=mdlTerminate(t,x,u);
  otherwise
    DAStudio.error('Simulink:blocks:unhandledFlag', num2str(flag));

end

%
function [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes

%
sizes = simsizes;

sizes.NumContStates  = 30;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 30;
sizes.NumInputs      = 30+15+15;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;   % at least one sample time is needed

sys = simsizes(sizes);

%
% initialize the initial conditions
%
 % x0  = [ 20 20 -1 0 0 0    -15 -5 -5 0 0 0    -25 25 -25 0 0 0     9 9 -9 0 0 0     15 -15 -35 0 0 0];
 x0  = [ 2 1 -2 0 0 0     3 4 -3 0 0 0     1 2 -1 0 0 0     -1 1 -2 0 0 0      1 -1 -1 0 0 0];
 % x0  = [ 2 1  3 0 0 0  5 3 1 0 0 0  4 2 0  0 0 0 3 2 2 0 0 0 2 2 1 0  0 0];

str = [];

%
% initialize the array of sample times
%
ts  = [0 0];

% Specify the block simStateCompliance. The allowed values are:
%    'UnknownSimState', < The default setting; warn and assume DefaultSimState
%    'DefaultSimState', < Same sim state as a built-in block
%    'HasNoSimState',   < No sim state
%    'DisallowSimState' < Error out when saving or restoring the model sim state
simStateCompliance = 'UnknownSimState';

% end mdlInitializeSizes

%
%=============================================================================
% mdlDerivatives
% Return the derivatives for the continuous states.
%=============================================================================
%
function sys=mdlDerivatives(t,x,u)
%第1个AUV
x1_1=x(1:3);
x2_1=x(4:6);
u_1=u(1:3);
fai_1=x(1);
th_1=x(2);

[M_bar_1, C_bar_1, D_bar_1, J_1]=get_AUV_systems(x1_1, x2_1);
%f
f_1=-inv(M_bar_1)*(C_bar_1*x2_1+D_bar_1*x2_1) ;
%d
u_ext=[0.1*sin(10*t);0.1*sin(10*t);0.1*cos(10*t)];

%dynimics
dx1=x2_1;
dx2=f_1 + inv(M_bar_1)*J_1*u_1 + u_ext;

sys(1:6) = [dx1;dx2];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%第2个AUV
x1_2=x(7:9);
x2_2=x(10:12);
u_2=u(4:6);
fai_2=x(7);
th_2=x(8);

[M_bar_2, C_bar_2, D_bar_2, J_2]=get_AUV_systems(x1_2, x2_2);
%f
f_2=-inv(M_bar_2)*(C_bar_2*x2_2+D_bar_2*x2_2) ;
%d
% u_ext=[0.1*sin(t);0.1*sin(t);0.1*sin(t)];

%dynimics
dx1_2=x2_2;
dx2_2=f_2 + inv(M_bar_2)*J_2*u_2 + u_ext;

sys(7:12) = [dx1_2;  dx2_2];

%------------------------------------------------------------------
%第3个AUV
x1_3=x(13:15);
x2_3=x(16:18);
u_3=u(7:9);
fai_3=x(13);
th_3=x(14);

[M_bar_3, C_bar_3, D_bar_3, J_3]=get_AUV_systems(x1_3, x2_3);
%f
f_3=-inv(M_bar_3)*(C_bar_3*x2_3+D_bar_3*x2_3) ;
%d
% u_ext=[0.1*sin(t);0.1*sin(t);0.1*sin(t)];
g_3=inv(M_bar_3)*J_3;
%dynimics
dx1_3=x2_3;
dx2_3=f_3+g_3*u_3+u_ext;

sys(13:18) = [dx1_3;dx2_3];
%---------------------------------------------------------------------------
%第4个AUV
x1_4=x(19:21);
x2_4=x(22:24);
u_4=u(10:12);
fai_4=x(19);
th_4=x(20);

[M_bar_4, C_bar_4, D_bar_4, J_4]=get_AUV_systems(x1_4, x2_4);
%f
f_4=-inv(M_bar_4)*(C_bar_4*x2_4+D_bar_4*x2_4) ;
g_4=inv(M_bar_4)*J_4;
%d
% u_ext=[0.1*sin(t);0.1*sin(t);0.1*sin(t)];

%dynimics
dx1_4=x2_4;
dx2_4=f_4+g_4*u_4+u_ext;

sys(19:24) = [dx1_4;dx2_4];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-----------------------------------
%第5个AUV
x1_5=x(25:27);
x2_5=x(28:30);
u_5=u(13:15);
fai_5=x(25);
th_5=x(26);

[M_bar_5, C_bar_5, D_bar_5, J_5]=get_AUV_systems(x1_5, x2_5);
%f
f_5=-inv(M_bar_5)*(C_bar_5*x2_5+D_bar_5*x2_5) ;
g_5=inv(M_bar_5)*J_5;
%d
% u_ext=[0.1*sin(t);0.1*sin(t);0.1*sin(t)];

%dynimics
dx1_5=x2_5;
dx2_5=f_5+g_5*u_5+u_ext;

sys(25:30) = [dx1_5; dx2_5];
% end mdlDerivatives

%
%=============================================================================
% mdlUpdate
% Handle discrete state updates, sample time hits, and major time step
% requirements.
%=============================================================================
%
function sys=mdlUpdate(t,x,u)

sys = [];

% end mdlUpdate

%
%=============================================================================
% mdlOutputs
% Return the block outputs.
%=============================================================================
%
function sys=mdlOutputs(t,x,u)
% xd=[sin(t);cos(t);0];
% dxd=[cos(t);-sin(t);0];
% ddxd=[-sin(t);-cos(t);0];
sys = [x];

% end mdlOutputs

%
%=============================================================================
% mdlGetTimeOfNextVarHit
% Return the time of the next hit for this block.  Note that the result is
% absolute time.  Note that this function is only used when you specify a
% variable discrete-time sample time [-2 0] in the sample time array in
% mdlInitializeSizes.
%=============================================================================
%
function sys=mdlGetTimeOfNextVarHit(t,x,u)

sampleTime = 1;    %  Example, set the next hit to be one second later.
sys = t + sampleTime;

% end mdlGetTimeOfNextVarHit

%
%=============================================================================
% mdlTerminate
% Perform any end of simulation tasks.
%=============================================================================
%
function sys=mdlTerminate(t,x,u)

sys = [];

% end mdlTerminate
