
function [M_bar, C_bar, D_bar, J]= get_AUV_systems(eta, nu)

% State variables
u = nu(1);    % surge velocity
v = nu(2);    % sway velocity
r = nu(3);    % yaw rate
phi = eta(3);
%% Inertia matrix
m11 = 200;
m22 = 250;
m33 = 80;

J = [ cos(phi)  -sin(phi)  0  ;
      sin(phi)  cos(phi)   0  ;
      0         0          1  ;];

dot_J =  [ -sin(phi)  -cos(phi)   0  ;
            cos(phi)  -sin(phi)   0  ;
            0         0           0  ;];

%% Damping matrix
d11 = 70 + 100*abs(u);
d22 = 100 + 200*abs(v);
d33 = 50 + 100*abs(r);

% Inertia matrix
M = [m11, 0,   0;
     0,   m22, 0;
     0,   0,   m33];

% Coriolis and centripetal matrix
C = [ 0,      0,      -m22*v;
      0,      0,       m11*u;
      m22*v, -m11*u,   0     ];

% Hydrodynamic damping matrix
D = [d11, 0,   0;
     0,   d22, 0;
     0,   0,   d33];


M_bar = J*M*inv(J);
C_bar = J*(C-M*inv(J)*dot_J)*inv(J);
D_bar = J*D*inv(J);


end