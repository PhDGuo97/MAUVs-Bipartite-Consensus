clc
clear
close all
load("data.mat")


data = [55.4 46.27 47.53 45.73 45.6];

figure
yyaxis left
bar(data,0.6)

yyaxis right
plot(1:5,data,'-o','LineWidth',2,...
     'MarkerSize',8)

xticks(1:5)
xticklabels({'AUV1','AUV2','AUV3','AUV4','AUV5'})

ylabel('Value')
grid on
box on

data = [55.4 46.27 47.53 45.73 45.6];

figure

% 柱状图
b = bar(data,0.6);
hold on

% 折线图
plot(1:5,data,'-o','LineWidth',2,...
    'MarkerSize',8);

% 在柱顶显示数值
for i = 1:length(data)
    text(i, data(i)+3, sprintf('%.2f',data(i)), ...
        'HorizontalAlignment','center', ...
        'FontSize',11,...
        'FontWeight','bold');
end

xticks(1:5)
xticklabels({'AUV1','AUV2','AUV3','AUV4','AUV5'})

ylabel(' Communication reduction $R_c$', 'Interpreter', 'latex');
grid on
box on

% 调整纵轴范围，避免文字超出
ylim([0 max(data)+5])












%% === Event-triggered "matchstick" plots ===
%  out.tout : [N×1] time
%  out.tri  : [N×6] triggers (columns = trig1..trig5, trigAny)

t  = out.tout(:);
tri = out.tri;



num_ones1 = sum(tri(:,1));
num_ones2 = sum(tri(:,2));
num_ones3 = sum(tri(:,3));
num_ones4 = sum(tri(:,4));
num_ones5 = sum(tri(:,5));
% Make tri match t's orientation if needed
if size(tri,1) ~= numel(t) && size(tri,2) == numel(t)
    tri = tri.';  % [6×N] -> [N×6]
end
assert(size(tri,1) == numel(t), 'out.tri rows must equal length(out.tout)');

nFollower = min(5, size(tri,2));
cols = lines(nFollower);

% ===== 触发模式 =====
% 'sample' : 每个 trig==1 的采样点都算一次触发（你现在需要）
% 'edge'   : 仅 0->1 上升沿算一次触发
trigger_mode = 'sample';

%% -------------------------------------------------------------
% 1) 事件时刻火柴图（每次触发一根竖线）
% -------------------------------------------------------------
figure('Name','Event Times (Matchstick Plot)','Color','w');
for i = 1:nFollower
    trig = tri(:,i) > 0.5;

    % 根据模式取事件索引
    if strcmp(trigger_mode,'edge')
        idx = find([false; diff(trig)==1]);   % 上升沿
    else
        idx = find(trig);                     % 每个为1的采样点
    end

    te = t(idx);

    subplot(nFollower,1,i); hold on;
    if ~isempty(te)
        line([te.'; te.'], [zeros(1,numel(te)); ones(1,numel(te))], ...
             'Color', cols(i,:), 'LineWidth', 0.8);
    end
    ylim([0 1]); yticks([]); box on;
    ylabel(sprintf('Follower%d', i));
    if i==nFollower, xlabel('Time (s)'); end
    title(sprintf('Event Times (Mode: %s)', trigger_mode));
end
count = 0 ;
%% -------------------------------------------------------------
% 2) 触发间隔火柴图（高度 = 相邻触发时间差 Δt）
% -------------------------------------------------------------
figure('Name','Event Intervals (Stem Plot)','Color','w');
for i = 1:nFollower
    trig = tri(:,i) > 0.5;
    
    if strcmp(trigger_mode,'edge')
        idx = find([false; diff(trig)==1]);
    else
        idx = find(trig);
    end

    te = t(idx);
    Ti = [NaN; diff(te)];   % 首个无前驱

    subplot(nFollower,1,i);
    if ~isempty(te)
        count = count+1;
        disp("count")
        disp(count);
        stem(te, Ti, 'o', ...
            'Color', cols(i,:), ...
            'MarkerFaceColor', 'none', ...   % <<< 空心圆
            'MarkerEdgeColor', cols(i,:), ...
            'LineWidth', 1.0);
        count = 0 ;
    else
        stem(NaN, NaN);
    end
    grid on; box on;
    ylabel({'$T_{in} $'}, 'Interpreter', 'latex');
    legend(sprintf('AUV%d', i), 'Location','northeast','FontSize', 10);
    set(gca, 'FontSize', 8, 'TickLabelInterpreter', 'latex');
    % 在顶部创建共享图例
% 创建共享图例（放在最上方）
% legend_labels = {'AUV1', 'AUV2', 'AUV3', 'AUV4', 'AUV5'};
% 
% % 方法1：使用annotation创建图例
% ax_legend = axes('Position', [0.3 0.92 0.4 0.05], 'Visible', 'off'); % 调整位置
% legend(ax_legend, legend_labels, ...
%        'Orientation', 'horizontal', ...
%        'NumColumns', 5, ...  % 水平排列7个图例项
%        'Box', 'off', ...
%        'FontSize', 8);
    if i==nFollower, xlabel('Time (s)'); end
    % title('Event Intervals');
end


%% -------------------------------------------------------------
% % 3) (可选) 合并触发 trigAny（第6列）
% % -------------------------------------------------------------
% if size(tri,2) >= 6
%     trigAny = tri(:,6) > 0.5;
%     if strcmp(trigger_mode,'edge')
%         idxAny = find([false; diff(trigAny)==1]);
%     else
%         idxAny = find(trigAny);
%     end
%     teAny = t(idxAny);
% 
%     figure('Name','Combined Trigger (trigAny)','Color','w'); hold on;
%     if ~isempty(teAny)
%         line([teAny.'; teAny.'], [zeros(1,numel(teAny)); ones(1,numel(teAny))], ...
%              'Color','k','LineWidth',0.8);
%     end
%     ylim([0 1]); yticks([]); box on;
%     xlabel('Time (s)'); ylabel('trigAny');
%     title(sprintf('Combined Event Times (Mode: %s)', trigger_mode));
% end
