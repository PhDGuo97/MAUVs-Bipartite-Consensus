close all;
smc=out.smc;
state=out.state;
input=out.input;
t=out.t1;

% 设置全局绘图样式
set(0, 'DefaultAxesFontSize', 16);
% set(0, 'DefaultLineLineWidth', 2);
% 修正的线型定义（统一使用元胞数组）
lineStyles = {
    {'-.', 'LineWidth', 2.0, 'Color', [0 0.45 0.74]},       % 第1行
    {'--', 'LineWidth', 2.0, 'Color', [0.85 0.33 0.10]},     % 第2行 
    {'--', 'LineWidth', 2.0, 'Color', [0.49 0.18 0.56],'Marker', '+', 'MarkerIndices', 1:50:length(t),...
     'MarkerSize', 5, 'MarkerFaceColor', 'auto'},     % 第4行
    {':',  'LineWidth', 2.5, 'Color', [0.93 0.69 0.13]},     % 第3行
    {'--', 'LineWidth', 2.5, 'Color', [0.47 0.67 0.19],...   % 第5行
     'Marker', 'o', 'MarkerIndices', 1:100:length(t),...
     'MarkerSize', 2, 'MarkerFaceColor', 'auto'}             % 增大标记尺寸
     {'-', 'LineWidth', 2.0, 'Color', [0.23 0.18 0.6],'Marker', '+', 'MarkerIndices', 1:50:length(t),...
     'MarkerSize', 5, 'MarkerFaceColor', 'auto'},     % 第4行
};
lineStyles2 = {
    {'-.', 'LineWidth', 2.0, 'Color', [0 0.45 0.74]},                                    % 1 蓝
    {'--', 'LineWidth', 2.0, 'Color', [0.85 0.33 0.10]},                                 % 2 橙

    {'--', 'LineWidth', 2.0, 'Color', [0.49 0.18 0.56], ...
     'Marker', '+', 'MarkerIndices', 1:120:length(t), ...
     'MarkerSize', 5},                                                                    % 3 紫

    {':', 'LineWidth', 2.5, 'Color', [0.93 0.69 0.13]},                                  % 4 黄

    {'--', 'LineWidth', 2.5, 'Color', [0.47 0.67 0.19], ...
     'Marker', 'o', 'MarkerIndices', 1:100:length(t), ...
     'MarkerSize', 5},                                                                    % 5 绿

    {'-', 'LineWidth', 2.0, 'Color', [0.23 0.18 0.60], ...
     'Marker', '+', 'MarkerIndices', 1:120:length(t), ...
     'MarkerSize', 5},                                                                    % 6 深蓝

    {'-.', 'LineWidth', 2.0, 'Color', [0.64 0.08 0.18], ...
     'Marker', 's', 'MarkerIndices', 1:120:length(t), ...
     'MarkerSize', 5},                                                                    % 7 酒红

    {':', 'LineWidth', 2.5, 'Color', [0.30 0.75 0.93], ...
     'Marker', 'd', 'MarkerIndices', 1:120:length(t), ...
     'MarkerSize', 5},                                                                    % 8 青蓝

    {'-', 'LineWidth', 2.0, 'Color', [0.25 0.25 0.25], ...
     'Marker', '^', 'MarkerIndices', 1:120:length(t), ...
     'MarkerSize', 5}                                                                     % 9 黑灰
};
colors = lines(6); % 使用MATLAB默认颜色矩阵
%% 1. 位置响应曲线 (Position)
figure(1)
set(gcf, 'Position', [100 100 800 500]); % 设置图形大小
for i = 1:5
    plot(t, state(:,1+(i-1)*6), 'LineStyle', lineStyles{i}{:}, 'Color', colors(i,:), 'LineWidth', 2);
    hold on;
end
plot(t, smc(:,1), 'k-', 'LineWidth', 2,'Marker', 'o',...
        'MarkerIndices', 1:100:length(t),...
        'MarkerSize', 2,...
        'MarkerFaceColor', [1 1 1]); % 领导者用黑色虚线
grid on; box on;

% 坐标轴标签（LaTeX格式）
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('x ($m$)', 'Interpreter', 'latex');
title('Multi-AUVs Consensus Tracking', 'Interpreter', 'latex');

% 图例（LaTeX格式，分两列显示）
% 添加图例（避免覆盖关键数据区域）
legend_labels = arrayfun(@(x)sprintf('AUV %d',x), 1:5, 'UniformOutput',false);
legend_labels{end+1} = 'Leader';
legend(legend_labels, 'Interpreter', 'latex', 'Location', 'northeastoutside');
% 设置线型区分（示例：第3条线改为点划线）
set(findobj(gca,'Type','Line','Color',[0 0.447 0.741]), 'LineStyle', '-.');
% 坐标轴优化
% xlim([t(1), t(end)]);
ylim padded % 自动扩展y轴范围
% set(gca, 'Layer', 'top'); % 确保网格在数据下方
%% 2. 位置响应曲线 (Position)
figure(2)
set(gcf, 'Position', [100 100 800 500]); % 设置图形大小
for i = 1:5
    plot(t, state(:,2+(i-1)*6), 'LineStyle', lineStyles{i}{:}, 'Color', colors(i,:), 'LineWidth', 2);
    hold on;
end
plot(t, smc(:,2), 'k-', 'LineWidth', 2,'Marker', 'o',...
        'MarkerIndices', 1:100:length(t),...
        'MarkerSize', 2,...
        'MarkerFaceColor', [1 1 1]); % 领导者用黑色虚线
grid on; box on;

% 坐标轴标签（LaTeX格式）
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('y ($m$)', 'Interpreter', 'latex');
title('Multi-AUVs Consensus Tracking', 'Interpreter', 'latex');

% 图例（LaTeX格式，分两列显示）
% legend({'$x_1$', '$x_2$', '$x_3$', '$x_4$', '$x_5$', '$x_0$'}, ...
%        'Interpreter', 'latex', 'Location', 'best', 'NumColumns', 2);
% 添加图例（避免覆盖关键数据区域）
legend_labels = arrayfun(@(x)sprintf('AUV %d',x), 1:5, 'UniformOutput',false);
legend_labels{end+1} = 'Leader';
legend(legend_labels, 'Interpreter', 'latex', 'Location', 'northeastoutside');
% 设置线型区分（示例：第3条线改为点划线）
% set(findobj(gca,'Type','Line','Color',[0 0.447 0.741]), 'LineStyle', '-.');
ylim([-3 6 ])

%% 3. 位置响应曲线 (Position)
figure(3)
set(gcf, 'Position', [100 100 800 500]); % 设置图形大小
for i = 1:5
    plot(t, state(:,3+(i-1)*6), 'LineStyle', lineStyles{i}{:}, 'Color', colors(i,:), 'LineWidth', 2);
    hold on;
end
plot(t, smc(:,3), 'k-', 'LineWidth', 2,'Marker', 'o',...
        'MarkerIndices', 1:100:length(t),...
        'MarkerSize', 2,...
        'MarkerFaceColor', [1 1 1]); % 领导者用黑色虚线
grid on; box on;

% 坐标轴标签（LaTeX格式）
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('z ($m$)', 'Interpreter', 'latex');
title('Multi-AUVs Consensus Tracking', 'Interpreter', 'latex');

% 图例（LaTeX格式，分两列显示）
% 添加图例（避免覆盖关键数据区域）
legend_labels = arrayfun(@(x)sprintf('AUV %d',x), 1:5, 'UniformOutput',false);
legend_labels{end+1} = 'Leader';
legend(legend_labels, 'Interpreter', 'latex', 'Location', 'northeastoutside');
% 设置线型区分（示例：第3条线改为点划线）
set(findobj(gca,'Type','Line','Color',[0 0.447 0.741]), 'LineStyle', '-.');
%% 4. 速度响应曲线 (Velocity)
figure(4)
set(gcf, 'Position', [100 100 800 500]); % 设置图形大小

colors = lines(5); % 使用MATLAB默认颜色矩阵

for i = 1:5
    plot(t, state(:,4+(i-1)*6), 'LineStyle', lineStyles{i}{:}, 'Color', colors(i,:), 'LineWidth', 2);
    hold on;
end
plot(t, smc(:,4), 'k-.', 'LineWidth', 2); % 领导者速度
grid on; box on;

xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Pitch ($\theta\,^\circ/s$)', 'Interpreter', 'latex');
title('Multi-AUVs Angular Velocity Tracking', 'Interpreter', 'latex');
legend_labels = arrayfun(@(x)sprintf('AUV %d',x), 1:5, 'UniformOutput',false);
legend_labels{end+1} = 'Leader';
legend(legend_labels, 'Interpreter', 'latex', 'Location', 'northeastoutside');
%% 5. 速度响应曲线 (Velocity)
figure(5)
set(gcf, 'Position', [100 100 800 500]); % 设置图形大小
colors = lines(6); % 使用MATLAB默认颜色矩阵

for i = 1:5
    plot(t, state(:,5+(i-1)*6), 'LineStyle', lineStyles{i}{:}, 'Color', colors(i,:), 'LineWidth', 2);
    hold on;
end
plot(t, smc(:,5), 'k-.', 'LineWidth', 2); % 领导者速度
grid on; box on;

xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Roll ($\phi\,^\circ/s$)', 'Interpreter', 'latex');
title('Multi-AUVs Angular Tracking', 'Interpreter', 'latex');
legend_labels = arrayfun(@(x)sprintf('AUV %d',x), 1:5, 'UniformOutput',false);
legend_labels{end+1} = 'Leader';
legend(legend_labels, 'Interpreter', 'latex', 'Location', 'northeastoutside');
%% 6. 速度响应曲线 (Velocity)
figure(6)
set(gcf, 'Position', [100 100 800 500]); % 设置图形大小
colors = lines(9); % 使用MATLAB默认颜色矩阵

for i = 1:5
    plot(t, state(:,6+(i-1)*6), 'LineStyle', lineStyles{i}{:}, 'Color', colors(i,:), 'LineWidth', 2);
    hold on;
end
plot(t, smc(:,6), 'k-.', 'LineWidth', 2); % 领导者速度
grid on; box on;

xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Yaw ($\psi\,^\circ/s$)', 'Interpreter', 'latex');
title('Multi-AUVs Angular Tracking', 'Interpreter', 'latex');
legend_labels = arrayfun(@(x)sprintf('AUV %d',x), 1:5, 'UniformOutput',false);
legend_labels{end+1} = 'Leader';
legend(legend_labels, 'Interpreter', 'latex', 'Location', 'northeastoutside');



figure(7);
set(gcf, 'Position', [100 100 800 600]); % 增大图形大小以适应3D视图

% 确保t是列向量
t = t(:);


hold on;
grid on; box on;

% 绘制智能体3D轨迹
for i = 1:5
    % 确保y数据列数足够
   
    % plot(t, state(:,6+(i-1)*6), 'LineStyle', linespec{i}, 'Color', colors(i,:), 'LineWidth', 2);
    hold on;
    % if size(y,2) >= i+5
        plot3(state(:,1+(i-1)*6), state(:,2+(i-1)*6), state(:,3+(i-1)*6), lineStyles{i}{:});
    % else
    %     warning('数据y的列数不足，跳过第%d个智能体', i);
    % end
end

% 绘制领导者3D轨迹（黑色实线+稀疏圆圈）
% if exist('smc','var') && size(y10,2) >= 2
    plot3(smc(:,1), smc(:,2), smc(:,3),'k-', 'LineWidth', 2.5,... 
        'Marker', 'o',...
        'MarkerIndices', 1:1000:length(t),...
        'MarkerSize', 2,...
        'MarkerFaceColor', [1 1 1]);
% else
%     warning('未找到有效的领导者数据y10');
% end

% 3D图形美化
set(gca, 'FontSize', 16, 'TickLabelInterpreter', 'latex');
% xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 16);
% ylabel('Position (m)', 'Interpreter', 'latex', 'FontSize', 16); % 修正Y轴标签
% zlabel('Velocity (m/s)', 'Interpreter', 'latex', 'FontSize', 16);
title('Multi-AUVs 3D Trajectory Tracking',...
      'Interpreter', 'latex', 'FontSize', 16);

% 添加图例（避免覆盖关键数据区域）
legend_labels = arrayfun(@(x)sprintf('AUV %d',x), 1:5, 'UniformOutput',false);
legend_labels{end+1} = 'Leader';
legend(legend_labels, 'Interpreter', 'latex', 'Location', 'northeastoutside');

% 优化3D视图
view(3); % 默认三维视角
rotate3d on; % 启用旋转功能
grid minor; % 添加次级网格
axis tight; % 紧凑坐标范围

% 设置透明度提升可读性
ax = gca;
ax.GridAlpha = 0.3; % 网格透明度
ax.XColor = [0.2 0.2 0.2]; % 坐标轴颜色
ax.YColor = [0.2 0.2 0.2];
ax.ZColor = [0.2 0.2 0.2];
xlabel('x')
ylabel('y')
zlabel('z')

%% 1. 滑模响应曲线 (Position)
figure
% set(gcf, 'Position', [100 100 800 500]); % 设置图形大小
for i = 1:6
    plot(t, input(:,16+(i-1)), 'LineStyle', lineStyles{i}{:}, 'Color', colors(i,:), 'LineWidth', 2);
    hold on;
end
% plot(t, smc(:,1), 'k-', 'LineWidth', 2,'Marker', 'o',...
%         'MarkerIndices', 1:100:length(t),...
%         'MarkerSize', 2,...
%         'MarkerFaceColor', [1 1 1]); % 领导者用黑色虚线
grid on; box on;

% 坐标轴标签（LaTeX格式）
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('s', 'Interpreter', 'latex');
title('Multi-AUVs Consensus Tracking', 'Interpreter', 'latex');
yline(0.1,'k--','LineWidth',1.5);
yline(-0.1,'k--','LineWidth',1.5);
% 图例（LaTeX格式，分两列显示）
% 添加图例（避免覆盖关键数据区域）
% legend_labels = arrayfun(@(x)sprintf('AUV %d',x), 1:5, 'UniformOutput',false);
% legend_labels{end+1} = 'Leader';
% legend(legend_labels, 'Interpreter', 'latex', 'Location', 'northeastoutside');
legend({'$s_{1,1}$', '$s_{1,2}$', '$s_{1,3}$', '$s_{2,1}$', '$s_{2,2}$', '$s_{2,3}$'}, ...
       'Interpreter', 'latex', 'Location', 'best', 'NumColumns', 2);
% 设置线型区分（示例：第3条线改为点划线）
set(findobj(gca,'Type','Line','Color',[0 0.447 0.741]), 'LineStyle', '-.');
% 坐标轴优化
% xlim([t(1), t(end)]);
ylim padded % 自动扩展y轴范围


%% 1. 滑模响应曲线 (Position)
figure
% set(gcf, 'Position', [100 100 800 500]); % 设置图形大小
for i = 1:9
    plot(t, input(:,22+(i-1)), 'LineStyle', lineStyles2{i}{:}, 'Color', colors(i,:), 'LineWidth', 2);
    hold on;
end
% plot(t, smc(:,1), 'k-', 'LineWidth', 2,'Marker', 'o',...
%         'MarkerIndices', 1:100:length(t),...
%         'MarkerSize', 2,...
%         'MarkerFaceColor', [1 1 1]); % 领导者用黑色虚线
grid on; box on;

% 坐标轴标签（LaTeX格式）
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('s', 'Interpreter', 'latex');
title('Multi-AUVs Sliding Trajectories', 'Interpreter', 'latex');
yline(0.1,'k--','LineWidth',1.5);
yline(-0.1,'k--','LineWidth',1.5);
% 图例（LaTeX格式，分两列显示）
% 添加图例（避免覆盖关键数据区域）
% legend_labels = arrayfun(@(x)sprintf('AUV %d',x), 1:5, 'UniformOutput',false);
% legend_labels{end+1} = 'Leader';
% legend(legend_labels, 'Interpreter', 'latex', 'Location', 'northeastoutside');
legend({'$s_{3,1}$', '$s_{3,2}$', '$s_{3,3}$', '$s_{4,1}$', '$s_{4,2}$', '$s_{4,3}$' ...
    , '$s_{5,1}$', '$s_{5,2}$', '$s_{5,3}$'}, ...
       'Interpreter', 'latex', 'Location', 'best', 'NumColumns', 2);
% 设置线型区分（示例：第3条线改为点划线）
set(findobj(gca,'Type','Line','Color',[0 0.447 0.741]), 'LineStyle', '-.');
% 坐标轴优化
% xlim([t(1), t(end)]);
ylim padded % 自动扩展y轴范围


figure
plot(t, input(:,16), 'LineWidth', 2);
hold on;
plot(t, input(:,17), 'LineWidth', 2);
plot(t, input(:,18), 'LineWidth', 2);
% plot(t, state(:,19), 'LineWidth', 2);
% plot(t, state(:,25), 'LineWidth', 2);
% plot(t, smc(:,1), 'k--', 'LineWidth', 1.5); % 领导者用黑色虚线
grid on; box on;

% 坐标轴标签（LaTeX格式）
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Sliding (m)', 'Interpreter', 'latex');
title('Multi-AUVs Sliding Trajectory', 'Interpreter', 'latex');

% 图例（LaTeX格式，分两列显示）
legend({'$s_1$', '$s_2$', '$s_3$', '$x_4$', '$x_5$', '$x_0$'}, ...
       'Interpreter', 'latex', 'Location', 'best', 'NumColumns', 2);

% 设置线型区分（示例：第3条线改为点划线）
set(findobj(gca,'Type','Line','Color',[0 0.447 0.741]), 'LineStyle', '-.');

%% 1. 滑模响应曲线 (Position)
figure
plot(t, input(:,19), 'LineWidth', 2);
hold on;
plot(t, input(:,20), 'LineWidth', 2);
plot(t, input(:,21), 'LineWidth', 2);
plot(t, input(:,22), 'LineWidth', 2);
hold on;
plot(t, input(:,23), 'LineWidth', 2);
plot(t, input(:,24), 'LineWidth', 2);
grid on; box on;

% 坐标轴标签（LaTeX格式）
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Sliding (m)', 'Interpreter', 'latex');
title('Multi-AUVs Sliding Trajectory', 'Interpreter', 'latex');
yline(0.1,'b--','LineWidth',1.5);
yline(-0.1,'b--','LineWidth',1.5);
% 图例（LaTeX格式，分两列显示）
legend({'$s_{1,1}$', '$s_{1,2}$', '$s_{1,3}$', '$s_{2,1}$', '$s_{2,2}$', '$s_{2,3}$'}, ...
       'Interpreter', 'latex', 'Location', 'best', 'NumColumns', 2);

% 设置线型区分（示例：第3条线改为点划线）
set(findobj(gca,'Type','Line','Color',[0 0.447 0.741]), 'LineStyle', '-.');

%% 1. 位置响应曲线 (Position)
figure
plot(t, input(:,22), 'LineWidth', 2);
hold on;
plot(t, input(:,23), 'LineWidth', 2);
plot(t, input(:,24), 'LineWidth', 2);
% plot(t, state(:,19), 'LineWidth', 2);
% plot(t, state(:,25), 'LineWidth', 2);
% plot(t, smc(:,1), 'k--', 'LineWidth', 1.5); % 领导者用黑色虚线
grid on; box on;

% 坐标轴标签（LaTeX格式）
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Sliding (m)', 'Interpreter', 'latex');
title('Multi-AUVs Sliding Trajectory', 'Interpreter', 'latex');

% 图例（LaTeX格式，分两列显示）
legend({'$s_1$', '$s_2$', '$s_3$', '$x_4$', '$x_5$', '$x_0$'}, ...
       'Interpreter', 'latex', 'Location', 'best', 'NumColumns', 2);

% 设置线型区分（示例：第3条线改为点划线）
set(findobj(gca,'Type','Line','Color',[0 0.447 0.741]), 'LineStyle', '-.');

%% 1. 位置响应曲线 (Position)
figure
plot(t, input(:,25), 'LineWidth', 2);
hold on;
plot(t, input(:,26), 'LineWidth', 2);
plot(t, input(:,27), 'LineWidth', 2);
% plot(t, state(:,19), 'LineWidth', 2);
% plot(t, state(:,25), 'LineWidth', 2);
% plot(t, smc(:,1), 'k--', 'LineWidth', 1.5); % 领导者用黑色虚线
grid on; box on;

% 坐标轴标签（LaTeX格式）
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Sliding (m)', 'Interpreter', 'latex');
title('Multi-AUVs Sliding Trajectory', 'Interpreter', 'latex');

% 图例（LaTeX格式，分两列显示）
legend({'$s_1$', '$s_2$', '$s_3$', '$x_4$', '$x_5$', '$x_0$'}, ...
       'Interpreter', 'latex', 'Location', 'best', 'NumColumns', 2);

% 设置线型区分（示例：第3条线改为点划线）
set(findobj(gca,'Type','Line','Color',[0 0.447 0.741]), 'LineStyle', '-.');

%% 1. 位置响应曲线 (Position)
figure
plot(t, input(:,28), 'LineWidth', 2);
hold on;
plot(t, input(:,29), 'LineWidth', 2);
plot(t, input(:,30), 'LineWidth', 2);
% plot(t, state(:,19), 'LineWidth', 2);
% plot(t, state(:,25), 'LineWidth', 2);
% plot(t, smc(:,1), 'k--', 'LineWidth', 1.5); % 领导者用黑色虚线
grid on; box on;

% 坐标轴标签（LaTeX格式）
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Sliding (m)', 'Interpreter', 'latex');
title('Multi-AUVs Sliding Trajectory', 'Interpreter', 'latex');

% 图例（LaTeX格式，分两列显示）
legend({'$s_1$', '$s_2$', '$s_3$', '$x_4$', '$x_5$', '$x_0$'}, ...
       'Interpreter', 'latex', 'Location', 'best', 'NumColumns', 2);

% 设置线型区分（示例：第3条线改为点划线）
set(findobj(gca,'Type','Line','Color',[0 0.447 0.741]), 'LineStyle', '-.');



%% 1. 误差响应曲线 (Position)
figure
plot(t, input(:,31), 'LineStyle',lineStyles{1}{:},'Color', colors(1,:), 'LineWidth',2);
hold on;
plot(t, input(:,32), 'LineStyle',lineStyles{2}{:}, 'LineWidth',2);
plot(t, input(:,33), 'LineStyle',lineStyles{3}{:},'LineWidth', 2);
plot(t, input(:,34), 'LineStyle',lineStyles{4}{:}, 'LineWidth',2);
hold on;
plot(t, input(:,35), 'LineStyle',lineStyles{5}{:}, 'LineWidth',2);
plot(t, input(:,36), 'LineWidth', 2);
% plot(t, state(:,19), 'LineWidth', 2);
% plot(t, state(:,25), 'LineWidth', 2);
% plot(t, smc(:,1), 'k--', 'LineWidth', 1.5); % 领导者用黑色虚线
grid on; box on;

% 坐标轴标签（LaTeX格式）
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Error (m)', 'Interpreter', 'latex');
title('Multi-AUVs Consensus Error', 'Interpreter', 'latex');

% 图例（LaTeX格式，分两列显示）
legend({'$e^p_{1,1}$', '$e^p_{1,2}$', '$e^p_{1,3}$', '$e^p_{2,1}$', '$e^p_{2,2}$', '$e^p_{2,3}$'}, ...
       'Interpreter', 'latex', 'Location', 'best', 'NumColumns', 2);

% 设置线型区分（示例：第3条线改为点划线）
set(findobj(gca,'Type','Line','Color',[0 0.447 0.741]), 'LineStyle', '-.');

%% 1. 误差响应曲线 (Position)
figure
plot(t, input(:,34), 'LineWidth', 2);
hold on;
plot(t, input(:,35), 'LineWidth', 2);
plot(t, input(:,36), 'LineWidth', 2);
% plot(t, state(:,19), 'LineWidth', 2);
% plot(t, state(:,25), 'LineWidth', 2);
% plot(t, smc(:,1), 'k--', 'LineWidth', 1.5); % 领导者用黑色虚线
grid on; box on;

% 坐标轴标签（LaTeX格式）
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Error (m)', 'Interpreter', 'latex');
title('Multi-AUVs Consensus Error', 'Interpreter', 'latex');

% 图例（LaTeX格式，分两列显示）
legend({'$e^p_{2,1}$', '$e^p_{2,2}$', '$e^p_{2,3}$'}, ...
       'Interpreter', 'latex', 'Location', 'best', 'NumColumns', 2);

% 设置线型区分（示例：第3条线改为点划线）
set(findobj(gca,'Type','Line','Color',[0 0.447 0.741]), 'LineStyle', '-.');

%% 1. 误差响应曲线 (Position)
figure
plot(t, input(:,37),'LineStyle',lineStyles{1}{:},'Color', colors(1,:), 'LineWidth', 2);
hold on;
plot(t, input(:,38), 'LineStyle',lineStyles{2}{:},'Color', colors(2,:),'LineWidth', 2);
plot(t, input(:,39), 'LineStyle',lineStyles{3}{:},'Color', colors(3,:),'LineWidth', 2);
plot(t, input(:,40), 'LineWidth', 2);
hold on;
plot(t, input(:,41), 'LineStyle',lineStyles{6}{:},'Color', colors(5,:),'LineWidth', 2);
plot(t, input(:,42), 'LineStyle',lineStyles{4}{:},'Color', colors(4,:),'LineWidth', 2);
plot(t, input(:,43), 'LineWidth', 2);
hold on;
plot(t, input(:,44),'LineStyle',lineStyles{5}{:},'Color', colors(5,:), 'LineWidth', 2);
plot(t, input(:,45), 'Color', colors(1,:), 'LineWidth', 2);
grid on; box on;

% 坐标轴标签（LaTeX格式）
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Error (m)', 'Interpreter', 'latex');
title('Multi-AUVs Consensus Error', 'Interpreter', 'latex');

% 图例（LaTeX格式，分两列显示）
legend({'$e^p_{3,1}$', '$e^p_{3,2}$', '$e^p_{3,3}$', '$e^p_{4,1}$', '$e^p_{4,2}$', '$e^p_{4,3}$', '$e^p_{5,1}$', '$e^p_{5,2}$', '$e^p_{5,3}$'}, ...
       'Interpreter', 'latex', 'Location', 'best', 'NumColumns', 2);

% 设置线型区分（示例：第3条线改为点划线）
set(findobj(gca,'Type','Line','Color',[0 0.447 0.741]), 'LineStyle', '-.');

%% 1. 误差响应曲线 (Position)
figure
plot(t, input(:,40), 'LineWidth', 2);
hold on;
plot(t, input(:,41), 'LineWidth', 2);
plot(t, input(:,42), 'LineWidth', 2);
grid on; box on;

% 坐标轴标签（LaTeX格式）
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Error (m)', 'Interpreter', 'latex');
title('Multi-AUVs Consensus Error', 'Interpreter', 'latex');

% 图例（LaTeX格式，分两列显示）
legend({'$e^p_{4,1}$', '$e^p_{4,2}$', '$e^p_{4,3}$'}, ...
       'Interpreter', 'latex', 'Location', 'best', 'NumColumns', 2);

% 设置线型区分（示例：第3条线改为点划线）
set(findobj(gca,'Type','Line','Color',[0 0.447 0.741]), 'LineStyle', '-.');


%% 1. 误差响应曲线 (Position)
figure
plot(t, input(:,43), 'LineWidth', 2);
hold on;
plot(t, input(:,44), 'LineWidth', 2);
plot(t, input(:,45), 'LineWidth', 2);
% plot(t, state(:,19), 'LineWidth', 2);
% plot(t, state(:,25), 'LineWidth', 2);
% plot(t, smc(:,1), 'k--', 'LineWidth', 1.5); % 领导者用黑色虚线
grid on; box on;

% 坐标轴标签（LaTeX格式）
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Error (m)', 'Interpreter', 'latex');
title('Multi-AUVs Consensus Error', 'Interpreter', 'latex');

% 图例（LaTeX格式，分两列显示）
legend({'$e^p_{5,1}$', '$e^p_{5,2}$', '$e^p_{5,3}$'}, ...
       'Interpreter', 'latex', 'Location', 'best', 'NumColumns', 2);

% 设置线型区分（示例：第3条线改为点划线）
set(findobj(gca,'Type','Line','Color',[0 0.447 0.741]), 'LineStyle', '-.');

%% 1. 增益响应曲线 (Position)
figure
plot(t, input(:,46), 'LineWidth', 2);
hold on;
plot(t, input(:,47), 'LineWidth', 2);
plot(t, input(:,48), 'LineWidth', 2);
% plot(t, input(:,49), 'LineWidth', 2);
% plot(t, input(:,50), 'LineWidth', 2);
% plot(t, smc(:,1), 'k--', 'LineWidth', 1.5); % 领导者用黑色虚线
grid on; box on;

% 坐标轴标签（LaTeX格式）
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Gain', 'Interpreter', 'latex');
title('Adaptive Super-Twisting Gain', 'Interpreter', 'latex');

% 图例（LaTeX格式，分两列显示）
legend({'$\varphi_{1}$', '$\varphi_{2}$', '$\varphi_{3}$', '$\varphi_4$', '$\varphi_5$'}, ...
       'Interpreter', 'latex', 'Location', 'best', 'NumColumns', 2);

% 设置线型区分（示例：第3条线改为点划线）
set(findobj(gca,'Type','Line','Color',[0 0.447 0.741]), 'LineStyle', '-.');

%% 1. 速度响应曲线 (Position)
figure
plot(t, input(:,46), 'LineStyle',lineStyles{1}{:},'Color', colors(1,:), 'LineWidth',2);
hold on;
plot(t, input(:,47), 'LineStyle',lineStyles{2}{:}, 'LineWidth',2);
plot(t, input(:,48), 'LineStyle',lineStyles{3}{:},'LineWidth', 2);
plot(t, input(:,49), 'LineStyle',lineStyles{4}{:}, 'LineWidth',2);
hold on;
plot(t, input(:,50), 'LineStyle',lineStyles{5}{:}, 'LineWidth',2);
plot(t, input(:,51), 'LineWidth', 2);
grid on; box on;

% 坐标轴标签（LaTeX格式）
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Error (m)', 'Interpreter', 'latex');
title('Multi-AUVs Consensus Error', 'Interpreter', 'latex');

% 图例（LaTeX格式，分两列显示）
legend({'$e^v_{1,1}$', '$e^v_{1,2}$', '$e^v_{1,3}$', '$e^v_{2,1}$', '$e^v_{2,2}$', '$e^v_{2,3}$'}, ...
       'Interpreter', 'latex', 'Location', 'best', 'NumColumns', 2);

% 设置线型区分（示例：第3条线改为点划线）
set(findobj(gca,'Type','Line','Color',[0 0.447 0.741]), 'LineStyle', '-.');

%% 1. 速度误差响应曲线 (Position)
figure
plot(t, input(:,52),'LineStyle',lineStyles{1}{:},'Color', colors(1,:), 'LineWidth', 2);
hold on;
plot(t, input(:,53), 'LineStyle',lineStyles{2}{:},'Color', colors(2,:),'LineWidth', 2);
plot(t, input(:,54), 'LineStyle',lineStyles{3}{:},'Color', colors(3,:),'LineWidth', 2);
plot(t, input(:,55), 'LineWidth', 2);
hold on;
plot(t, input(:,56), 'LineStyle',lineStyles{6}{:},'Color', colors(5,:),'LineWidth', 2);
plot(t, input(:,57), 'LineStyle',lineStyles{4}{:},'Color', colors(4,:),'LineWidth', 2);
plot(t, input(:,58), 'LineWidth', 2);
hold on;
plot(t, input(:,59),'LineStyle',lineStyles{5}{:},'Color', colors(5,:), 'LineWidth', 2);
plot(t, input(:,60), 'Color', colors(1,:), 'LineWidth', 2);
grid on; box on;

% 坐标轴标签（LaTeX格式）
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Error (m)', 'Interpreter', 'latex');
title('Multi-AUVs Consensus Error', 'Interpreter', 'latex');

% 图例（LaTeX格式，分两列显示）
legend({'$e^v_{3,1}$', '$e^v_{3,2}$', '$e^v_{3,3}$', '$e^v_{4,1}$', '$e^v_{4,2}$', '$e^v_{4,3}$', '$e^v_{5,1}$', '$e^v_{5,2}$', '$e^v_{5,3}$'}, ...
       'Interpreter', 'latex', 'Location', 'best', 'NumColumns', 2);

% 设置线型区分（示例：第3条线改为点划线）
set(findobj(gca,'Type','Line','Color',[0 0.447 0.741]), 'LineStyle', '-.');

