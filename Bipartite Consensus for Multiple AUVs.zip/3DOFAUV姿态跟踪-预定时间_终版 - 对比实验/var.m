clear all
close all
clc

global uc1;
global uc2;
global uc3;
global uc4;
global uc5;
global j ; 
global hate1 ;
global hate2 ;
global hate3 ;
global hate4 ;
global hate5;
% u1=zeros(3,1)
uc1=[ 0 0 0]';
uc2=[ 0 0 0]';
uc3=[ 0 0 0]';
uc4=[ 0 0 0]';
uc5=[ 0 0 0]';
hate1=[ 0 0 0]';
hate2=[ 0 0 0]';
hate3=[ 0 0 0]';
hate4=[ 0 0 0]';
hate5=[ 0 0 0]';
j = 1 ;