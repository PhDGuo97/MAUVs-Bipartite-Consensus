clc;  close all;

% RMSE = [
%     0.1234 0.2345 0.3456;
%     0.1123 0.2234 0.3345;
%     0.1012 0.2123 0.3234;
%     0.0987 0.1876 0.2765;
%     0.0876 0.1765 0.2654
% ];

RMSE = [
    RMSE11 RMSE12 RMSE13;
    RMSE21 RMSE22 RMSE23;
    RMSE31 RMSE32 RMSE33;
    RMSE41 RMSE42 RMSE43;
    RMSE51 RMSE52 RMSE53
];

disp('RMSE Matrix = ');
disp(RMSE);
figure('Color','w');
hold on

%% 分组柱状图
b = bar(RMSE,'grouped');

b(1).FaceColor = [0 0.4470 0.7410];
b(2).FaceColor = [0.8500 0.3250 0.0980];
b(3).FaceColor = [0.4660 0.6740 0.1880];

%% 获取柱中心位置
ngroups = size(RMSE,1);
nbars   = size(RMSE,2);

groupwidth = min(0.8, nbars/(nbars+1.5));

xpos = zeros(ngroups,nbars);

for k = 1:nbars
    xpos(:,k) = (1:ngroups) ...
        - groupwidth/2 ...
        + (2*k-1)*groupwidth/(2*nbars);
end

%% 折线图
plot(xpos(:,1),RMSE(:,1),'-o',...
    'LineWidth',2,...
    'MarkerSize',7,...
    'Color',[0 0.4470 0.7410]);

plot(xpos(:,2),RMSE(:,2),'-s',...
    'LineWidth',2,...
    'MarkerSize',7,...
    'Color',[0.8500 0.3250 0.0980]);

plot(xpos(:,3),RMSE(:,3),'-^',...
    'LineWidth',2,...
    'MarkerSize',7,...
    'Color',[0.4660 0.6740 0.1880]);

%% 数值标签
for i = 1:ngroups
    for j = 1:nbars
        text(xpos(i,j),...
             RMSE(i,j)+0.005,...
             sprintf('%.3f',RMSE(i,j)),...
             'HorizontalAlignment','center',...
             'FontSize',10,...
             'FontWeight','bold');
    end
end

%% 坐标轴设置
set(gca,...
    'FontSize',12,...
    'FontName','Times New Roman');

xlabel('AUV Index','FontSize',13);
ylabel('RMSE','FontSize',13);

xticks(1:5);
xticklabels({'AUV1','AUV2','AUV3','AUV4','AUV5'});

legend({'RMSE-x','RMSE-y','RMSE-z'},...
       'Location','northwest');

grid on
box on

ylim([0 0.42])

title('RMSE Comparison of Five AUVs');

figure

b = bar(RMSE,'grouped');

b(1).FaceColor = [0 0.447 0.741];
b(2).FaceColor = [0.850 0.325 0.098];
b(3).FaceColor = [0.466 0.674 0.188];

xlabel('AUV Index')
ylabel('RMSE')

xticklabels({'AUV1','AUV2','AUV3','AUV4','AUV5'})

legend('x-axis','y-axis','z-axis')

grid on
box on

figure

imagesc(RMSE)

colormap(parula)
colorbar

xticks(1:3)
xticklabels({'x','y','z'})

yticks(1:5)
yticklabels({'AUV1','AUV2','AUV3','AUV4','AUV5'})