function [sys,x0,str,ts] = SMC_input2(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 1,
    sys=mdlDerivatives(t,x,u);
case 3,
    sys=mdlOutputs(t,x,u);
case {2,4,9}
    sys=[];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 9;
sizes.NumInputs      = 0;
sizes.DirFeedthrough = 0;
sizes.NumSampleTimes = 1;
sys = simsizes(sizes);
x0  = [];
str = [];
ts  = [0 0];            %ts是一个1×2的向量，ts(1)是采样周期，ts(2)是偏移量

% function sys=mdlDerivatives(t,x,u)
% % u0=0.8*sin(2*t)*cos(5*t);   
% % if t<=6
% %     u0=t*sin(2*t) ;
% % elseif (6<t)&&(t<10)
% %    u0=0.5*t ;
% % else
% %     u0=0.2*cos(t);  
% % end
% xd=[sin(t);cos(t);0];
% dxd=[cos(t);-sin(t);0];
% ddxd=[-sin(t);-cos(t);0];


function sys=mdlOutputs(t,x,u)
xd=[sin(t);cos(t);2];
dxd=[cos(t);-sin(t);0];
ddxd=[-sin(t);-cos(t);0];
% xd=[sin(t);cos(t);sin(t)];
% dxd=[cos(t);-sin(t);cos(t)];
% ddxd=[-sin(t);-cos(t);-sin(t)];
% xd=[sin(t);cos(t);-0.5*t];
% dxd=[cos(t);-sin(t);-0.5];
% ddxd=[-sin(t);-cos(t);0];
sys(1:3)=xd;
sys(4:6)=dxd;
sys(7:9)=ddxd;
% sys(7:9)= [t*sin(2*t) ;t*sin(2*t) ;t*sin(2*t) ];%x0t
% sys(2)=x(2); 
% if t<=6
%     u0=t*sin(2*t) ;
% elseif (6<t)&&(t<10)
%    u0=0.5*t ;
% else
%     u0=0.2*cos(t);  
% end
% %v0t
% sys(3)=u0;      %u0t


