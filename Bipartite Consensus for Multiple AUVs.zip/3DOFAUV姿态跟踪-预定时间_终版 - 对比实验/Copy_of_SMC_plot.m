close all;

smc=out.smc;
state=out.state;
input=out.input;
% Th1=out.Time;
% err=Th-[smc(:,1);smc(:,2);smc(:,3);smc(:,4);smc(:,5);smc(:,6)];
t=out.t1;
% figure(1);
% plot(t,smc(:,1),'b--',t,smc(:,2),'k--',t,smc(:,3),'r--','linewidth',1.5);
% hold on 
% plot(t,state(:,1),'k',t,state(:,2),'b',t,state(:,3),'r','linewidth',1.5);
% plot(t,state(:,7),t,state(:,8),t,state(:,9),'linewidth',1.5);
% plot(t,state(:,13),t,state(:,14),t,state(:,15),'linewidth',1.5);
% plot(t,state(:,19),t,state(:,20),t,state(:,21),'linewidth',1.5);
% plot(t,state(:,25),t,state(:,26),t,state(:,27),'linewidth',1.5);
% xlabel('时间');
% ylabel('角度');
% legend('θ','Φ','ψ','θd','Φd','ψd');
figure(1);
set(gcf, 'Position', [100 100 900 600], 'Color', 'w'); % 设置图形大小和背景

% 1. 定义线型和颜色方案（领导者与跟随者区分）
lineStyles = {
    % 领导者（smc） - 虚线
    {'--', 'Color', [0 0 1], 'LineWidth', 2},   % 蓝色虚线 (θ)
    {'--', 'Color', [0 0 0], 'LineWidth', 2},   % 黑色虚线 (Φ)
    {'--', 'Color', [1 0 0], 'LineWidth', 2},   % 红色虚线 (ψ)
    
    % 跟随者（state） - 实线+不同颜色
    {'-', 'Color', [0 0.5 0], 'LineWidth', 1.5},    % 绿色实线 (无人机1)
    {'-', 'Color', [0.8 0 0.8], 'LineWidth', 1.5},  % 紫色实线 (无人机2)
    {'-', 'Color', [0 0.7 0.7], 'LineWidth', 1.5},  % 青色实线 (无人机3)
    {'-', 'Color', [0.9 0.6 0], 'LineWidth', 1.5},  % 橙色实线 (无人机4)
    {'-', 'Color', [0.4 0.4 0.4], 'LineWidth', 1.5} % 灰色实线 (无人机5)
};

% 2. 绘制轨迹
hold on; grid on; box on;

% 绘制领导者轨迹（smc）
plot(t, smc(:,1), lineStyles{1}{:});
% plot(t, smc(:,2), lineStyles{2}{:});
% plot(t, smc(:,3), lineStyles{3}{:});

% 绘制跟随者轨迹（state）
plot(t, state(:,1), lineStyles{4}{:});  % 无人机1
plot(t, state(:,2), lineStyles{5}{:});  % 无人机2
plot(t, state(:,3), lineStyles{6}{:});  % 无人机3
plot(t, state(:,7), lineStyles{7}{:});  % 无人机4
plot(t, state(:,13), lineStyles{8}{:}); % 无人机5

% 3. 添加关键点标记（起点和终点）
markerSize = 80;
scatter(t(1), smc(1,1), markerSize, 'b', 'filled', 'MarkerEdgeColor', 'k');
scatter(t(end), smc(end,1), markerSize, 'b', 'MarkerEdgeColor', 'k');
scatter(t(1), state(1,1), markerSize, [0 0.5 0], 'filled', 'MarkerEdgeColor', 'k');

% 4. 坐标轴和图例设置
xlabel('Time (s)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Attitude (rad)', 'FontSize', 12, 'FontWeight', 'bold');
title('UAV consensus', 'FontSize', 14, 'FontWeight', 'bold');

% 分两列显示的图例
legend({
    'Leader' ...
    'UAV1', 'UAV2', 'UAV3', ...
    'UAV4', 'UAV5', ...
    }, ...
    'Location', 'bestoutside', 'NumColumns', 2, 'FontSize', 10);

% 5. 图形美化
ax = gca;
ax.GridLineStyle = '-';
ax.GridAlpha = 0.2;
ax.FontName = 'Arial';
xlim([t(1) t(end)]); % 自动调整X轴范围

% 6. 添加分组标注（示例）
text(mean(t), max(ylim)-0.1, '第一组', 'Color', 'b', 'FontSize', 11);
text(mean(t), min(ylim)+0.1, '第二组', 'Color', 'r', 'FontSize', 11);

figure(2);
plot(t,smc(:,1),'k','linewidth',1.5);

hold on 
plot(t,state(:,1),'r','linewidth',1.5);
plot(t,state(:,7),'c','linewidth',1.5);
plot(t,state(:,13),'g--','linewidth',1.5);
plot(t,state(:,19),'y-.','linewidth',1.5);
plot(t,state(:,25),'r:','linewidth',1.5);
xlabel('时间');
ylabel('角度');
legend('Leader','UAV1','UAV2','UAV3','UAV4','UAV5');

figure(3);
plot(t,smc(:,2),'k','linewidth',1.5);

hold on 
plot(t,state(:,2),'r','linewidth',1.5);
plot(t,state(:,8),'c','linewidth',1.5);
plot(t,state(:,14),'g--','linewidth',1.5);
plot(t,state(:,20),'y-.','linewidth',1.5);
plot(t,state(:,26),'r:','linewidth',1.5);
xlabel('时间');
ylabel('角度');
legend('Leader','UAV1','UAV2','UAV3','UAV4','UAV5');

figure(4);
plot(t,state(:,3),'r','linewidth',1.5);
hold on 
plot(t,smc(:,3),'r','linewidth',1.5);
xlabel('时间');
ylabel('角度');
legend('θ','Φ','ψ');

figure(5);
plot(t,state(:,1)-smc(:,1),'linewidth',1.5);
hold on 
plot(t,state(:,2)-smc(:,2),'linewidth',1.5);
plot(t,state(:,3)-smc(:,3),'linewidth',1.5);
plot(t,state(:,4)-smc(:,4),'linewidth',1.5);
plot(t,state(:,5)-smc(:,5),'linewidth',1.5);
plot(t,state(:,6)-smc(:,6),'linewidth',1.5);
xlabel('时间');
ylabel('误差');
legend('θ','Φ','ψ','dθ','dΦ','dψ');

figure(6);
plot(t,state(:,1)-smc(:,1),'linewidth',1.5);
hold on 
plot(t,state(:,2)-smc(:,2),'linewidth',1.5);
plot(t,state(:,3)-smc(:,3),'linewidth',1.5);
xlabel('时间');
ylabel('误差');
legend('θ','Φ','ψ');

% figure(7);
% 
% plot(t,Th1(:,1)-smc(:,1),'linewidth',1.5);
% hold on
% plot(t,Th1(:,2)-smc(:,2),'linewidth',1.5);
% plot(t,Th1(:,3)-smc(:,3),'linewidth',1.5);
% xlabel('时间');
% ylabel('误差');
% legend('dθ','dΦ','dψ');

figure(8)
plot(t,input(:,16),input(:,17),input(:,18),'linewidth',1.5);

figure
plot(t,input(:,19),input(:,20),input(:,21),'linewidth',1.5);
figure
plot(t,input(:,22),input(:,23),input(:,24),'linewidth',1.5);
figure
plot(t,input(:,25),input(:,26),input(:,27),'linewidth',1.5);
figure
plot(t,input(:,28),input(:,29),input(:,30),'linewidth',1.5);

figure(9);
plot(t,state(:,7)-smc(:,1),'linewidth',1.5);
hold on 
plot(t,state(:,8)-smc(:,2),'linewidth',1.5);
plot(t,state(:,9)-smc(:,3),'linewidth',1.5);
plot(t,state(:,10)-smc(:,4),'linewidth',1.5);
plot(t,state(:,11)-smc(:,5),'linewidth',1.5);
plot(t,state(:,12)-smc(:,6),'linewidth',1.5);
xlabel('时间');
ylabel('误差');
legend('θ','Φ','ψ','dθ','dΦ','dψ');

% err1=state(:,1:6)-[smc(:,1);smc(:,2);smc(:,3);smc(:,4);smc(:,5);smc(:,6)];
% plot(t,err1,'linewidth',1.5);
figure(10);
set(gcf, 'Position', [100 100 1000 800], 'Color', 'w'); % 设置图形大小和背景色

% 自定义线型和颜色组合
lineStyles = {
    {'-',  'Color', [0 0 0], 'LineWidth', 1.5},       % 黑色实线 (Agent 1)
    {'--', 'Color', [0 0 1], 'LineWidth', 1.5},       % 蓝色虚线 (Agent 2)
    {'-.', 'Color', [1 0 0], 'LineWidth', 1.5},       % 红色点划线 (Agent 3)
    {':',  'Color', [0 0.5 0], 'LineWidth', 2},       % 绿色点线 (Agent 4)
    {'-',  'Color', [0.7 0 0.7], 'LineWidth', 1.5},   % 紫色实线 (Agent 5)
    {'--', 'Color', [0 0.7 0.7], 'LineWidth', 1.5}    % 青色虚线 (Leader)
};

% 绘制轨迹
hold on;
grid on; box on;

% Agent 1-5 和 Leader 的轨迹
plot3(smc(:,1), smc(:,2), smc(:,3), lineStyles{2}{:});
plot3(state(:,1), state(:,2), state(:,3), lineStyles{1}{:});
plot3(state(:,7), state(:,8), state(:,9), lineStyles{3}{:});
plot3(state(:,13), state(:,14), state(:,15), lineStyles{4}{:});
plot3(state(:,19), state(:,20), state(:,21), lineStyles{5}{:});
plot3(state(:,25), state(:,26), state(:,27), lineStyles{6}{:});

% 添加标记点（每隔100个数据点显示一个）
% markerStep = 100;
% scatter3(state(1:markerStep:end,1), state(1:markerStep:end,2), state(1:markerStep:end,3),...
%     40, 'k', 'filled', 'MarkerEdgeColor', 'w');
% scatter3(smc(1:markerStep:end,1), smc(1:markerStep:end,2), smc(1:markerStep:end,3),...
%     40, 'b', 'filled', 'MarkerEdgeColor', 'w');

% 坐标轴标签（LaTeX格式）
xlabel('X Position (m)', 'Interpreter', 'latex', 'FontSize', 14);
ylabel('Y Position (m)', 'Interpreter', 'latex', 'FontSize', 14);
zlabel('Z Position (m)', 'Interpreter', 'latex', 'FontSize', 14);
title('3D Trajectory of Multi-Agent System', 'Interpreter', 'latex', 'FontSize', 16);

% 图例设置
legend({'Leader', 'Agent 1', 'Agent 2', 'Agent 3', 'Agent 4', 'Agent 5', ...
  },...
       'Interpreter', 'latex', 'Location', 'bestoutside', 'FontSize', 12);

% 视角调整
view(3); % 默认三维视角
rotate3d on; % 启用鼠标旋转

% 坐标轴美化
ax = gca;
ax.GridLineStyle = '-';
ax.GridAlpha = 0.3;
ax.FontName = 'Arial';
ax.FontSize = 12;
ax.XColor = [0.2 0.2 0.2];
ax.YColor = [0.2 0.2 0.2];
ax.ZColor = [0.2 0.2 0.2];

% 添加颜色条说明（可选）
% colorbar('Ticks',[], 'TickLabels',{'','',''},...
%          'Position',[0.85 0.2 0.02 0.6],...
%          'Color',[0.3 0.3 0.3]);


figure(11);
set(gcf, 'Position', [100 100 900 700], 'Color', 'w'); % 设置图形大小和背景色

% 1. 数据准备
t = 0:0.1:15; % 时间轴（示例，替换为实际时间向量）
agents = {'Agent 1', 'Agent 2', 'Agent 3', 'Agent 4', 'Agent 5', 'Leader'};

% 2. 颜色和线型定义（匹配参考图风格）
colors = [
    0 0 0;    % 黑
    0 0 1;    % 蓝
    1 0 0;    % 红
    0 0.5 0;  % 深绿
    0.5 0 0.5;% 紫
    0 0 0     % 黑（Leader）
];
lineStyles = {'-', '-', '-', '-', '-', '--'}; % Leader用虚线

% 3. 绘制3D轨迹
hold on; grid on; box on;
for i = 1:6
    % 计算对应列索引（示例：假设数据按[x1,y1,z1,x2,y2,z2,...]排列）
    cols = (1:3) + (i-1)*3;
    
    % 绘制轨迹
    plot3(state(:,cols(1)), state(:,cols(2)), state(:,cols(3)), ...
        'Color', colors(i,:), 'LineStyle', lineStyles{i}, 'LineWidth', 1.5);
    
    % 添加起始/终点标记
    scatter3(state(1,cols(1)), state(1,cols(2)), state(1,cols(3)), ...
        80, colors(i,:), 'filled', 'Marker', 'o');
    scatter3(state(end,cols(1)), state(end,cols(2)), state(end,cols(3)), ...
        80, colors(i,:), 'filled', 'Marker', '^');
end

% 4. 坐标轴设置
xlabel('Position (m)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Velocity (m/s)', 'FontSize', 12, 'FontWeight', 'bold');
zlabel('Height (m)', 'FontSize', 12, 'FontWeight', 'bold');
title('Multi-Agent 3D Trajectory Tracking', 'FontSize', 14, 'FontWeight', 'bold');
xlim([0,3])
% 5. 图例优化（匹配参考图位置）
legend(agents, 'Location', 'northeastoutside', 'FontSize', 10);

% 6. 视角和范围设置
view(30, 30); % 调整视角
axis tight;
xlim([0 15]); % 匹配参考图X轴范围
ylim([-20 20]); % 匹配参考图Y轴范围
grid minor;

% 7. 添加参考线（可选）
plot3([0 15], [0 0], [0 0], 'k:', 'LineWidth', 0.5); % X轴参考线

% 8. 图形美化
ax = gca;
ax.GridAlpha = 0.2;
ax.LineWidth = 1.2;
ax.FontName = 'Arial';
ax.XTick = 0:5:15; % 匹配参考图刻度

figure(12);
plot(t,state(:,13)-smc(:,1),'linewidth',1.5);
hold on 
plot(t,state(:,14)-smc(:,2),'linewidth',1.5);
plot(t,state(:,15)-smc(:,3),'linewidth',1.5);
plot(t,state(:,16)-smc(:,4),'linewidth',1.5);
plot(t,state(:,17)-smc(:,5),'linewidth',1.5);
plot(t,state(:,18)-smc(:,6),'linewidth',1.5);
xlabel('时间');
ylabel('误差');
legend('θ','Φ','ψ','dθ','dΦ','dψ');

figure(13);
plot(t,smc(:,1),'linewidth',1.5);
hold on 
plot(t,state(:,1),'linewidth',1.5);
plot(t,state(:,7),'linewidth',1.5);
plot(t,state(:,13),'linewidth',1.5);
plot(t,state(:,19),'linewidth',1.5);
plot(t,state(:,25),'linewidth',1.5);
xlabel('时间');
ylabel('角度');
legend('θ','Φ','ψ','θd','Φd','ψd');